import picker from "@ohos:file.picker";
import fs from "@ohos:file.fs";
import media from "@ohos:multimedia.media";
import image from "@ohos:multimedia.image";
import util from "@ohos:util";
import hilog from "@ohos:hilog";
import type { BusinessError } from "@ohos:base";
const DOMAIN = 0x0002; // Unique domain for VideoService
const TAG = 'VideoService';
// 定义具体的错误类型接口，替代Record<string, unknown>
interface ErrorInfo {
    code?: number;
    message?: string;
}
// 视频信息接口
export interface VideoInfo {
    duration: number; // 视频时长（秒）
    width: number; // 视频宽度
    height: number; // 视频高度
    fps?: number; // 视频帧率（可选）
}
// 播放器状态枚举（根据media类型定义）
enum PlayerState {
    IDLE = 0,
    INITIALIZED = 1,
    PREPARED = 2,
    PLAYING = 3,
    PAUSED = 4,
    COMPLETED = 5,
    STOPPED = 6,
    RELEASED = 7,
    ERROR = 8
}
// 使用正确的参数类型
// 注意：fetchFrameByTime 方法需要 PixelMapParams 类型的参数
// 定义视频源接口
interface VideoSource {
    fd: number;
}
// 定义帧提取结果接口
interface FrameResult {
    timeUs: number;
    pixelMap: image.PixelMap | null;
}
export class VideoService {
    /**
     * 从相册选择视频文件
     * @returns 选中视频的URI，如果用户取消则为空字符串
     */
    async selectVideoFromGallery(): Promise<string> {
        try {
            // 使用DocumentViewPicker代替FilePicker (为了兼容性)
            const documentPicker = new picker.DocumentViewPicker();
            const options = new picker.DocumentSelectOptions();
            options.fileSuffixFilters = ['.mp4', '.avi', '.mov', '.mkv']; // 支持的视频格式示例
            hilog.info(DOMAIN, TAG, 'Showing DocumentViewPicker for video selection...');
            const result = await documentPicker.select(options);
            if (result && result.length > 0) {
                const videoUri = result[0];
                hilog.info(DOMAIN, TAG, `Selected video URI: ${videoUri}`);
                return videoUri;
            }
            else {
                hilog.info(DOMAIN, TAG, 'No video selected or selection cancelled by user.');
                return '';
            }
        }
        catch (err) {
            let errorMessage = '选择视频时发生未知错误';
            let errorCode = -1;
            // 不使用 'in' 运算符
            if (typeof err === 'object' && err !== null) {
                // 安全地访问属性
                errorCode = err.code !== undefined ? err.code : -1;
                errorMessage = err.message !== undefined ? err.message : errorMessage;
                // 通过错误码或消息检查用户取消
                if (errorCode === 1001 || (errorMessage && errorMessage.toLowerCase().includes('cancel'))) {
                    hilog.warn(DOMAIN, TAG, 'User cancelled video selection.');
                    return '';
                }
            }
            hilog.error(DOMAIN, TAG, `Failed to select video, code: ${errorCode}, message: ${errorMessage}`);
            throw new Error(`选择视频失败: ${errorMessage} (代码: ${errorCode})`);
        }
    }
    /**
     * 获取视频文件的基本信息
     * @param videoUri 视频文件的URI
     * @returns VideoInfo对象，包含视频的基本信息
     */
    async getVideoInfo(videoUri: string): Promise<VideoInfo | null> {
        if (!videoUri) {
            hilog.error(DOMAIN, TAG, 'Video URI is empty for getting video info');
            return null;
        }
        let avPlayer: media.AVPlayer | null = null;
        let videoFile: fs.File | null = null;
        try {
            // Open the video file to get a file descriptor
            try {
                videoFile = await fs.open(videoUri, fs.OpenMode.READ_ONLY);
                hilog.info(DOMAIN, TAG, `Video file opened for info, fd: ${videoFile.fd} for URI: ${videoUri}`);
            }
            catch (openError) {
                hilog.error(DOMAIN, TAG, `Failed to open video file for info: ${openError.message}`);
                throw new Error(`打开视频文件失败: ${openError.message}`);
            }
            // 创建临时播放器获取视频信息
            avPlayer = await media.createAVPlayer();
            if (!avPlayer) {
                hilog.error(DOMAIN, TAG, 'Failed to create AVPlayer for video info');
                // Ensure fd is closed if player creation fails after opening file
                if (videoFile)
                    await fs.close(videoFile.fd);
                return null;
            }
            hilog.info(DOMAIN, TAG, `Getting info for video with fd: ${videoFile.fd}`);
            avPlayer.url = `fd://${videoFile.fd}`;
            // 等待播放器准备完成
            return new Promise<VideoInfo | null>((resolve, reject) => {
                // 自定义准备状态变化处理函数
                const onPlayerPrepared = () => {
                    // 获取视频信息
                    const videoInfo: VideoInfo = {
                        duration: avPlayer?.duration || 0,
                        width: avPlayer?.width || 0,
                        height: avPlayer?.height || 0,
                        fps: 30 // 默认值，大多数情况下AVPlayer无法直接获取fps
                    };
                    hilog.info(DOMAIN, TAG, `Video info retrieved: ${JSON.stringify(videoInfo)}`);
                    // 释放播放器资源
                    avPlayer?.release().then(() => {
                        resolve(videoInfo);
                    }).catch((err: BusinessError) => {
                        hilog.warn(DOMAIN, TAG, `Failed to release player after getting info: ${JSON.stringify(err)}`);
                        resolve(videoInfo); // 即使释放失败，仍然返回信息
                    });
                };
                // 简化的错误处理
                const onPlayerError = (errMsg: string) => {
                    avPlayer?.release().catch(() => { });
                    reject(new Error(errMsg));
                };
                // 实际事件监听
                if (avPlayer) {
                    avPlayer.prepare().then(() => {
                        onPlayerPrepared(); // 在准备完成后调用
                    }).catch((err: BusinessError) => {
                        hilog.error(DOMAIN, TAG, `Player prepare error: ${JSON.stringify(err)}`);
                        onPlayerError('获取视频信息时播放器准备出错');
                    });
                }
                // 设置超时
                setTimeout(() => {
                    onPlayerError('获取视频信息超时');
                }, 10000); // 10秒超时
            });
        }
        catch (err) {
            let errorMessage: string = '获取视频信息时发生未知错误';
            let errorCode: number = -1;
            if (typeof err === 'object' && err !== null) {
                const errorObject = err as ErrorInfo;
                if (errorObject.message !== undefined) {
                    errorMessage = errorObject.message;
                }
                if (errorObject.code !== undefined) {
                    errorCode = errorObject.code;
                }
            }
            hilog.error(DOMAIN, TAG, `Failed to get video info: ${errorMessage} (Code: ${errorCode !== -1 ? errorCode : 'N/A'})`);
            return null;
        }
        finally {
            if (avPlayer) {
                try {
                    await avPlayer.release();
                    hilog.info(DOMAIN, TAG, 'AVPlayer released after getting video info.');
                }
                catch (releaseError) {
                    hilog.error(DOMAIN, TAG, `Failed to release AVPlayer: ${releaseError.message}`);
                }
            }
            if (videoFile) {
                try {
                    await fs.close(videoFile.fd);
                    hilog.info(DOMAIN, TAG, `Closed video file (for info) fd: ${videoFile.fd}`);
                }
                catch (closeError) {
                    hilog.error(DOMAIN, TAG, `Failed to close video file (for info) fd: ${closeError.message}`);
                }
            }
        }
    }
    /**
     * 从视频URI提取指定时间的帧
     * @param videoUri 视频文件的URI
     * @param timeUs 提取帧的时间点，单位为微秒 (e.g., 1 second = 1_000_000 microseconds)
     * @returns PixelMap 对象，如果失败则为 null
     */
    async getVideoFrameAtTime(videoUri: string, timeUs: number): Promise<image.PixelMap | null> {
        if (!videoUri) {
            hilog.error(DOMAIN, TAG, 'Video URI is empty for frame extraction.');
            return null;
        }
        hilog.info(DOMAIN, TAG, `Extracting frame from URI: ${videoUri} at ${timeUs}us`);
        let videoFile: fs.File | null = null;
        let avImageGenerator: media.AVImageGenerator | null = null;
        try {
            // videoFile = fs.openSync(videoUri, fs.OpenMode.READ_ONLY); // <-- Old sync open
            try {
                videoFile = await fs.open(videoUri, fs.OpenMode.READ_ONLY); // <-- New async open
                hilog.info(DOMAIN, TAG, `Video file opened for frame extraction, fd: ${videoFile.fd}`);
            }
            catch (openError) {
                hilog.error(DOMAIN, TAG, `Failed to open video file for frame extraction: ${openError.message}`);
                throw new Error(`打开视频文件失败 (帧提取): ${openError.message}`);
            }
            // 检查API是否支持
            if (media.createAVImageGenerator) {
                avImageGenerator = await media.createAVImageGenerator();
                if (avImageGenerator) {
                    const videoSource: VideoSource = { fd: videoFile.fd };
                    avImageGenerator.fdSrc = videoSource;
                }
                else {
                    hilog.error(DOMAIN, TAG, 'Failed to create AVImageGenerator');
                    return null;
                }
            }
            else {
                hilog.error(DOMAIN, TAG, 'createAVImageGenerator API is not supported on this device');
                return null;
            }
            const queryOption = media.AVImageQueryOptions.AV_IMAGE_QUERY_NEXT_SYNC;
            hilog.info(DOMAIN, TAG, `Fetching frame at time ${timeUs}us with option ${queryOption}`);
            try {
                // 检查API是否支持
                if (avImageGenerator.fetchFrameByTime) {
                    try {
                        // 定义一个空接口来满足类型检查，并作为第三个参数传递
                        interface FrameFetchParams {
                        }
                        const fetchParams: FrameFetchParams = {};
                        // 使用三个参数调用 fetchFrameByTime
                        const pixelMap = await avImageGenerator.fetchFrameByTime(timeUs, queryOption, fetchParams);
                        if (pixelMap) {
                            hilog.info(DOMAIN, TAG, 'Frame fetched successfully.');
                            return pixelMap;
                        }
                        else {
                            hilog.error(DOMAIN, TAG, 'fetchFrameByTime returned null');
                            return null;
                        }
                    }
                    catch (error) {
                        hilog.error(DOMAIN, TAG, `Error in fetchFrameByTime: ${JSON.stringify(error)}`);
                        return null;
                    }
                }
                else {
                    hilog.error(DOMAIN, TAG, 'fetchFrameByTime API is not supported on AVImageGenerator');
                    return null;
                }
            }
            catch (fetchError) {
                hilog.error(DOMAIN, TAG, `Error during fetchFrameByTime: ${JSON.stringify(fetchError)}`);
                return null;
            }
        }
        catch (error) {
            let errorMessage: string = '提取视频帧时发生未知错误';
            let errorCode: number = -1;
            if (typeof error === 'object' && error !== null) {
                const errorObject = error as ErrorInfo;
                if (errorObject.message !== undefined) {
                    errorMessage = errorObject.message;
                }
                if (errorObject.code !== undefined) {
                    errorCode = errorObject.code;
                }
            }
            hilog.error(DOMAIN, TAG, `Failed to get video frame: ${errorMessage} (Code: ${errorCode !== -1 ? errorCode : 'N/A'})`);
            return null;
        }
        finally {
            if (avImageGenerator) {
                try {
                    await avImageGenerator.release();
                    hilog.info(DOMAIN, TAG, 'AVImageGenerator released.');
                }
                catch (releaseError) {
                    hilog.error(DOMAIN, TAG, `Failed to release AVImageGenerator: ${releaseError.message}`);
                }
            }
            if (videoFile) {
                try {
                    await fs.close(videoFile.fd);
                    hilog.info(DOMAIN, TAG, `Closed video file (for frame extraction) fd: ${videoFile.fd}`);
                }
                catch (closeError) {
                    hilog.error(DOMAIN, TAG, `Failed to close video file (for frame extraction) fd: ${closeError.message}`);
                }
            }
        }
    }
    /**
     * 从视频中提取多个帧
     * @param videoUri 视频文件URI
     * @param startTimeUs 开始时间（微秒）
     * @param endTimeUs 结束时间（微秒）
     * @param frameCount 要提取的帧数
     * @returns 帧提取结果数组，每个元素包含时间和像素图
     */
    async extractMultipleFrames(videoUri: string, startTimeUs: number, endTimeUs: number, frameCount: number): Promise<Array<FrameResult>> {
        if (!videoUri || frameCount <= 0 || startTimeUs >= endTimeUs) {
            hilog.error(DOMAIN, TAG, `Invalid parameters for extracting multiple frames: uri=${videoUri}, start=${startTimeUs}, end=${endTimeUs}, count=${frameCount}`);
            return [];
        }
        const results: Array<FrameResult> = [];
        const timeStep = Math.floor((endTimeUs - startTimeUs) / (frameCount - 1));
        hilog.info(DOMAIN, TAG, `Starting extraction of ${frameCount} frames from ${startTimeUs}us to ${endTimeUs}us with step ${timeStep}us`);
        for (let i = 0; i < frameCount; i++) {
            const currentTimeUs = startTimeUs + (i * timeStep);
            const pixelMap = await this.getVideoFrameAtTime(videoUri, currentTimeUs);
            // 创建一个符合 FrameResult 接口的对象
            const frameResult: FrameResult = {
                timeUs: currentTimeUs,
                pixelMap: pixelMap
            };
            results.push(frameResult);
            hilog.info(DOMAIN, TAG, `Extracted frame ${i + 1}/${frameCount} at ${currentTimeUs}us: ${pixelMap ? 'success' : 'failed'}`);
        }
        return results;
    }
    /**
     * 将 PixelMap 对象转换为 Base64 编码的字符串 (带MIME类型前缀)
     * @param pixelMap 要转换的 PixelMap 对象
     * @param format 图片格式, e.g., "image/jpeg", "image/png". 默认 "image/jpeg".
     * @param quality 图片质量 (0-100), 仅对 "image/jpeg" 和 "image/webp" 有效. 默认 90.
     * @returns Base64 编码的图片数据 (e.g., "data:image/jpeg;base64,...")，如果失败则为空字符串
     */
    async convertPixelMapToBase64(pixelMap: image.PixelMap, format: string = "image/jpeg", quality: number = 90): Promise<string> {
        if (!pixelMap) {
            hilog.error(DOMAIN, TAG, 'PixelMap is null for Base64 conversion.');
            return "";
        }
        hilog.info(DOMAIN, TAG, `Converting PixelMap to Base64. Format: ${format}, Quality: ${quality}`);
        try {
            // 检查API是否支持
            if (!image.createImagePacker) {
                hilog.error(DOMAIN, TAG, 'createImagePacker API is not supported on this device');
                return "";
            }
            const imagePackerApi = image.createImagePacker();
            if (!imagePackerApi) {
                hilog.error(DOMAIN, TAG, 'Failed to create ImagePacker');
                return "";
            }
            const packOption: image.PackingOption = {
                format: format,
                quality: quality
            };
            // 检查packing方法是否可用
            if (!imagePackerApi.packing) {
                hilog.error(DOMAIN, TAG, 'ImagePacker.packing API is not supported on this device');
                return "";
            }
            const arrayBuffer = await imagePackerApi.packing(pixelMap, packOption);
            if (!arrayBuffer || arrayBuffer.byteLength === 0) {
                hilog.error(DOMAIN, TAG, 'Packed PixelMap resulted in empty ArrayBuffer.');
                return "";
            }
            // 检查Base64Helper API是否支持
            if (typeof util.Base64Helper !== 'function') {
                hilog.error(DOMAIN, TAG, 'Base64Helper API is not supported on this device');
                return "";
            }
            const base64Helper = new util.Base64Helper();
            if (!base64Helper) {
                hilog.error(DOMAIN, TAG, 'Failed to create Base64Helper');
                return "";
            }
            const uint8Array = new Uint8Array(arrayBuffer);
            // 检查encodeToStringSync方法是否可用
            if (!base64Helper.encodeToStringSync) {
                hilog.error(DOMAIN, TAG, 'Base64Helper.encodeToStringSync API is not supported on this device');
                return "";
            }
            const base64Data = base64Helper.encodeToStringSync(uint8Array);
            const fullBase64String = `data:${format};base64,${base64Data}`;
            hilog.info(DOMAIN, TAG, `PixelMap converted to Base64 successfully (first 100 chars): ${fullBase64String.substring(0, 100)}...`);
            return fullBase64String;
        }
        catch (err) {
            let errorMessage: string = '转换PixelMap到Base64时发生未知错误';
            let errorCode: number = -1;
            if (typeof err === 'object' && err !== null) {
                const errorObject = err as ErrorInfo;
                if (errorObject.message !== undefined) {
                    errorMessage = errorObject.message;
                }
                if (errorObject.code !== undefined) {
                    errorCode = errorObject.code;
                }
            }
            hilog.error(DOMAIN, TAG, `Failed to convert PixelMap to Base64: ${errorMessage} (Code: ${errorCode !== -1 ? errorCode : 'N/A'})`);
            return "";
        }
    }
}
