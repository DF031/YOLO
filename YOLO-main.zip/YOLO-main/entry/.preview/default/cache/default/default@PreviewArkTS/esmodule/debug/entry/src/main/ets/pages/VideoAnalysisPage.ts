if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface VideoAnalysisPage_Params {
    videoUri?: string;
    videoInfo?: VideoInfo | null;
    errorMessage?: string;
    isConnected?: boolean;
    isLoading?: boolean;
    currentPosition?: number;
    isPlaying?: boolean;
    selectedInterval?: ExtractionInterval;
    analysisResults?: FrameAnalysisResult[];
    selectedFrameIndex?: number;
    isExtractingFrames?: boolean;
    extractionProgress?: number;
    totalFramesToExtract?: number;
    isContinuousAnalysisMode?: boolean;
    xComponentWidth?: string | number;
    xComponentHeight?: string | number;
    avPlayer?: media.AVPlayer | null;
    webSocketService?: WebSocketService;
    videoService?: VideoService;
    currentFd?: number;
    xcomponentController?: XComponentController;
    surfaceID?: string;
}
import hilog from "@ohos:hilog";
import promptAction from "@ohos:promptAction";
import type image from "@ohos:multimedia.image";
import router from "@ohos:router";
import media from "@ohos:multimedia.media";
import type { BusinessError } from "@ohos:base";
import fs from "@ohos:file.fs";
import display from "@ohos:display";
import { WebSocketService } from "@normalized:N&&&entry/src/main/ets/services/WebSocketService&";
import { VideoService } from "@normalized:N&&&entry/src/main/ets/services/VideoService&";
import type { VideoInfo } from "@normalized:N&&&entry/src/main/ets/services/VideoService&";
import type { PlateInfo } from '../model/MessageTypes';
import { CommonConstants } from "@normalized:N&&&entry/src/main/ets/common/constants/CommonConstants&";
import { PlateResultItem } from "@normalized:N&&&entry/src/main/ets/components/PlateResultItem&";
import { PlateAnnotatorCanvas } from "@normalized:N&&&entry/src/main/ets/components/PlateAnnotatorCanvas&";
const DOMAIN = 0x0002;
const TAG = 'VideoAnalysisPage';
// 提取间隔选项（秒）
enum ExtractionInterval {
    ONE_SECOND = 1,
    THREE_SECONDS = 3,
    FIVE_SECONDS = 5,
    TEN_SECONDS = 10
}
// 帧分析结果数据结构
interface FrameAnalysisResult {
    frameId: number;
    timeUs: number;
    timeFormatted: string;
    pixelMap: image.PixelMap | null;
    imageInfo: image.ImageInfo | null;
    plates: PlateInfo[];
    isAnalyzing: boolean;
}
// 用于更新分析结果的接口
interface AnalysisResultUpdate {
    frameId?: number;
    timeUs?: number;
    timeFormatted?: string;
    pixelMap?: image.PixelMap | null;
    imageInfo?: image.ImageInfo | null;
    plates?: PlateInfo[];
    isAnalyzing?: boolean;
}
// XComponent context的接口定义
interface XComponentContext {
    getXComponentSurfaceId(): string;
}
class VideoAnalysisPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__videoUri = new ObservedPropertySimplePU('', this, "videoUri");
        this.__videoInfo = new ObservedPropertyObjectPU(null, this, "videoInfo");
        this.__errorMessage = new ObservedPropertySimplePU('', this, "errorMessage");
        this.__isConnected = new ObservedPropertySimplePU(false, this, "isConnected");
        this.__isLoading = new ObservedPropertySimplePU(false, this, "isLoading");
        this.__currentPosition = new ObservedPropertySimplePU(0, this, "currentPosition");
        this.__isPlaying = new ObservedPropertySimplePU(false, this, "isPlaying");
        this.__selectedInterval = new ObservedPropertySimplePU(ExtractionInterval.THREE_SECONDS, this, "selectedInterval");
        this.__analysisResults = new ObservedPropertyObjectPU([], this, "analysisResults");
        this.__selectedFrameIndex = new ObservedPropertySimplePU(-1, this, "selectedFrameIndex");
        this.__isExtractingFrames = new ObservedPropertySimplePU(false, this, "isExtractingFrames");
        this.__extractionProgress = new ObservedPropertySimplePU(0, this, "extractionProgress");
        this.__totalFramesToExtract = new ObservedPropertySimplePU(0, this, "totalFramesToExtract");
        this.__isContinuousAnalysisMode = new ObservedPropertySimplePU(false, this, "isContinuousAnalysisMode");
        this.__xComponentWidth = new ObservedPropertySimplePU('100%', this, "xComponentWidth");
        this.__xComponentHeight = new ObservedPropertySimplePU(220, this, "xComponentHeight");
        this.avPlayer = null;
        this.webSocketService = new WebSocketService();
        this.videoService = new VideoService();
        this.currentFd = -1;
        this.xcomponentController = new XComponentController();
        this.surfaceID = '';
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: VideoAnalysisPage_Params) {
        if (params.videoUri !== undefined) {
            this.videoUri = params.videoUri;
        }
        if (params.videoInfo !== undefined) {
            this.videoInfo = params.videoInfo;
        }
        if (params.errorMessage !== undefined) {
            this.errorMessage = params.errorMessage;
        }
        if (params.isConnected !== undefined) {
            this.isConnected = params.isConnected;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
        if (params.currentPosition !== undefined) {
            this.currentPosition = params.currentPosition;
        }
        if (params.isPlaying !== undefined) {
            this.isPlaying = params.isPlaying;
        }
        if (params.selectedInterval !== undefined) {
            this.selectedInterval = params.selectedInterval;
        }
        if (params.analysisResults !== undefined) {
            this.analysisResults = params.analysisResults;
        }
        if (params.selectedFrameIndex !== undefined) {
            this.selectedFrameIndex = params.selectedFrameIndex;
        }
        if (params.isExtractingFrames !== undefined) {
            this.isExtractingFrames = params.isExtractingFrames;
        }
        if (params.extractionProgress !== undefined) {
            this.extractionProgress = params.extractionProgress;
        }
        if (params.totalFramesToExtract !== undefined) {
            this.totalFramesToExtract = params.totalFramesToExtract;
        }
        if (params.isContinuousAnalysisMode !== undefined) {
            this.isContinuousAnalysisMode = params.isContinuousAnalysisMode;
        }
        if (params.xComponentWidth !== undefined) {
            this.xComponentWidth = params.xComponentWidth;
        }
        if (params.xComponentHeight !== undefined) {
            this.xComponentHeight = params.xComponentHeight;
        }
        if (params.avPlayer !== undefined) {
            this.avPlayer = params.avPlayer;
        }
        if (params.webSocketService !== undefined) {
            this.webSocketService = params.webSocketService;
        }
        if (params.videoService !== undefined) {
            this.videoService = params.videoService;
        }
        if (params.currentFd !== undefined) {
            this.currentFd = params.currentFd;
        }
        if (params.xcomponentController !== undefined) {
            this.xcomponentController = params.xcomponentController;
        }
        if (params.surfaceID !== undefined) {
            this.surfaceID = params.surfaceID;
        }
    }
    updateStateVars(params: VideoAnalysisPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__videoUri.purgeDependencyOnElmtId(rmElmtId);
        this.__videoInfo.purgeDependencyOnElmtId(rmElmtId);
        this.__errorMessage.purgeDependencyOnElmtId(rmElmtId);
        this.__isConnected.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__currentPosition.purgeDependencyOnElmtId(rmElmtId);
        this.__isPlaying.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedInterval.purgeDependencyOnElmtId(rmElmtId);
        this.__analysisResults.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedFrameIndex.purgeDependencyOnElmtId(rmElmtId);
        this.__isExtractingFrames.purgeDependencyOnElmtId(rmElmtId);
        this.__extractionProgress.purgeDependencyOnElmtId(rmElmtId);
        this.__totalFramesToExtract.purgeDependencyOnElmtId(rmElmtId);
        this.__isContinuousAnalysisMode.purgeDependencyOnElmtId(rmElmtId);
        this.__xComponentWidth.purgeDependencyOnElmtId(rmElmtId);
        this.__xComponentHeight.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__videoUri.aboutToBeDeleted();
        this.__videoInfo.aboutToBeDeleted();
        this.__errorMessage.aboutToBeDeleted();
        this.__isConnected.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        this.__currentPosition.aboutToBeDeleted();
        this.__isPlaying.aboutToBeDeleted();
        this.__selectedInterval.aboutToBeDeleted();
        this.__analysisResults.aboutToBeDeleted();
        this.__selectedFrameIndex.aboutToBeDeleted();
        this.__isExtractingFrames.aboutToBeDeleted();
        this.__extractionProgress.aboutToBeDeleted();
        this.__totalFramesToExtract.aboutToBeDeleted();
        this.__isContinuousAnalysisMode.aboutToBeDeleted();
        this.__xComponentWidth.aboutToBeDeleted();
        this.__xComponentHeight.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __videoUri: ObservedPropertySimplePU<string>;
    get videoUri() {
        return this.__videoUri.get();
    }
    set videoUri(newValue: string) {
        this.__videoUri.set(newValue);
    }
    private __videoInfo: ObservedPropertyObjectPU<VideoInfo | null>;
    get videoInfo() {
        return this.__videoInfo.get();
    }
    set videoInfo(newValue: VideoInfo | null) {
        this.__videoInfo.set(newValue);
    }
    private __errorMessage: ObservedPropertySimplePU<string>;
    get errorMessage() {
        return this.__errorMessage.get();
    }
    set errorMessage(newValue: string) {
        this.__errorMessage.set(newValue);
    }
    private __isConnected: ObservedPropertySimplePU<boolean>;
    get isConnected() {
        return this.__isConnected.get();
    }
    set isConnected(newValue: boolean) {
        this.__isConnected.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    private __currentPosition: ObservedPropertySimplePU<number>; // 当前播放位置（秒）
    get currentPosition() {
        return this.__currentPosition.get();
    }
    set currentPosition(newValue: number) {
        this.__currentPosition.set(newValue);
    }
    private __isPlaying: ObservedPropertySimplePU<boolean>;
    get isPlaying() {
        return this.__isPlaying.get();
    }
    set isPlaying(newValue: boolean) {
        this.__isPlaying.set(newValue);
    }
    private __selectedInterval: ObservedPropertySimplePU<ExtractionInterval>;
    get selectedInterval() {
        return this.__selectedInterval.get();
    }
    set selectedInterval(newValue: ExtractionInterval) {
        this.__selectedInterval.set(newValue);
    }
    private __analysisResults: ObservedPropertyObjectPU<FrameAnalysisResult[]>;
    get analysisResults() {
        return this.__analysisResults.get();
    }
    set analysisResults(newValue: FrameAnalysisResult[]) {
        this.__analysisResults.set(newValue);
    }
    private __selectedFrameIndex: ObservedPropertySimplePU<number>;
    get selectedFrameIndex() {
        return this.__selectedFrameIndex.get();
    }
    set selectedFrameIndex(newValue: number) {
        this.__selectedFrameIndex.set(newValue);
    }
    private __isExtractingFrames: ObservedPropertySimplePU<boolean>;
    get isExtractingFrames() {
        return this.__isExtractingFrames.get();
    }
    set isExtractingFrames(newValue: boolean) {
        this.__isExtractingFrames.set(newValue);
    }
    private __extractionProgress: ObservedPropertySimplePU<number>;
    get extractionProgress() {
        return this.__extractionProgress.get();
    }
    set extractionProgress(newValue: number) {
        this.__extractionProgress.set(newValue);
    }
    private __totalFramesToExtract: ObservedPropertySimplePU<number>;
    get totalFramesToExtract() {
        return this.__totalFramesToExtract.get();
    }
    set totalFramesToExtract(newValue: number) {
        this.__totalFramesToExtract.set(newValue);
    }
    private __isContinuousAnalysisMode: ObservedPropertySimplePU<boolean>;
    get isContinuousAnalysisMode() {
        return this.__isContinuousAnalysisMode.get();
    }
    set isContinuousAnalysisMode(newValue: boolean) {
        this.__isContinuousAnalysisMode.set(newValue);
    }
    // 用于动态控制XComponent尺寸
    private __xComponentWidth: ObservedPropertySimplePU<string | number>; // 初始宽度
    get xComponentWidth() {
        return this.__xComponentWidth.get();
    }
    set xComponentWidth(newValue: string | number) {
        this.__xComponentWidth.set(newValue);
    }
    private __xComponentHeight: ObservedPropertySimplePU<string | number>; // 初始高度 (vp)
    get xComponentHeight() {
        return this.__xComponentHeight.get();
    }
    set xComponentHeight(newValue: string | number) {
        this.__xComponentHeight.set(newValue);
    }
    // 控制器和服务
    private avPlayer: media.AVPlayer | null;
    private webSocketService: WebSocketService;
    private videoService: VideoService;
    private currentFd: number; // 用于保存文件描述符
    private xcomponentController: XComponentController;
    async aboutToAppear() {
        // 获取路由参数
        interface RouterParams {
            videoUri?: string;
        }
        const params = router.getParams() as RouterParams;
        if (params && params.videoUri) {
            this.videoUri = params.videoUri;
            await this.initVideoPlayer();
        }
        else {
            this.errorMessage = '无效的视频URI参数';
            // 3秒后返回到上一页
            setTimeout(() => {
                router.back();
            }, 3000);
        }
        // 初始化WebSocket
        this.initWebSocketService();
    }
    aboutToDisappear() {
        this.releaseResources();
    }
    async initVideoPlayer() {
        if (!this.videoUri)
            return;
        try {
            // 释放之前可能存在的播放器和文件描述符
            if (this.avPlayer) {
                await this.avPlayer.release();
                this.avPlayer = null;
            }
            if (this.currentFd !== -1) {
                try {
                    await fs.close(this.currentFd);
                    this.currentFd = -1;
                }
                catch (closeError) {
                    hilog.error(DOMAIN, TAG, `Error closing previous fd: ${closeError.message}`);
                }
            }
            // 打开文件获取文件描述符
            try {
                const file = await fs.open(this.videoUri, fs.OpenMode.READ_ONLY);
                this.currentFd = file.fd;
                hilog.info(DOMAIN, TAG, `Video file opened, fd: ${this.currentFd} for URI: ${this.videoUri}`);
            }
            catch (openError) {
                this.errorMessage = `打开视频文件失败: ${openError.message}`;
                hilog.error(DOMAIN, TAG, this.errorMessage);
                return;
            }
            // 创建AVPlayer实例
            this.avPlayer = await media.createAVPlayer();
            // 设置状态变化回调
            this.avPlayer.on('stateChange', (state: string, reason: media.StateChangeReason) => {
                hilog.info(DOMAIN, TAG, `Player state changed to: ${state}, reason: ${reason}`);
                switch (state) {
                    case 'idle':
                        hilog.info(DOMAIN, TAG, 'AVPlayer state idle called.');
                        // 在idle状态，通常在设置url后会自动转到initialized
                        // 保留之前的逻辑：如果XComponent.onAppear后发现player是idle，它会设置url
                        break;
                    case 'initialized':
                        hilog.info(DOMAIN, TAG, 'AVPlayer state initialized called.');
                        if (this.avPlayer) { // 确保播放器实例存在
                            // 如果播放器的 surfaceId 尚未设置，但页面的 this.surfaceID (从 XComponent.onAppear 获取) 已有值，则设置它
                            if (!this.avPlayer.surfaceId && this.surfaceID) {
                                hilog.info(DOMAIN, TAG, `Player 'initialized': avPlayer.surfaceId is not set, but this.surfaceID (${this.surfaceID}) is available. Setting it on avPlayer.`);
                                this.avPlayer.surfaceId = this.surfaceID;
                            }
                            // 现在，如果 surfaceId 真正设置在播放器实例上，则准备播放器
                            if (this.avPlayer.surfaceId) {
                                // 只有当播放器确实处于 'initialized' 状态时才调用 prepare，避免在其他状态（如已 prepared 或更高）时重复调用
                                if (this.avPlayer.state === 'initialized') {
                                    hilog.info(DOMAIN, TAG, `Player 'initialized': avPlayer.surfaceId (${this.avPlayer.surfaceId}) is set. Calling prepare().`);
                                    this.avPlayer.prepare(); // 准备播放器
                                }
                                else {
                                    hilog.info(DOMAIN, TAG, `Player 'initialized': avPlayer.surfaceId (${this.avPlayer.surfaceId}) is set, but player state is already ${this.avPlayer.state}. Not calling prepare() here.`);
                                }
                            }
                            else {
                                // 如果 surfaceId 仍然无效/未设置，说明 XComponent.onAppear 可能还没执行完，
                                // 或者执行了但没成功获取 surfaceId。XComponent.onAppear 中的逻辑会尝试调用 prepare。
                                hilog.warn(DOMAIN, TAG, 'Player \'initialized\': avPlayer.surfaceId is still not set. Waiting for XComponent.onAppear to set surfaceId and call prepare().');
                            }
                        }
                        break;
                    case 'prepared':
                        // 准备完成，可以获取媒体信息
                        hilog.info(DOMAIN, TAG, `AVPlayer state prepared called. SurfaceId: ${this.surfaceID}`);
                        if (this.avPlayer) {
                            const durationMs = this.avPlayer.duration;
                            const durationInSeconds = durationMs > 0 ? durationMs / 1000 : 0;
                            this.videoInfo = {
                                duration: durationInSeconds,
                                width: this.avPlayer.width,
                                height: this.avPlayer.height, // 获取视频高度
                                // fps: 0 // AVPlayer通常不直接提供fps，如果需要，需其他方法获取
                            };
                            hilog.info(DOMAIN, TAG, `Video info obtained from player: ${JSON.stringify(this.videoInfo)}`);
                            // 设置视频缩放模式以适应XComponent，保持宽高比
                            this.avPlayer.videoScaleType = media.VideoScaleType.VIDEO_SCALE_TYPE_FIT;
                            hilog.info(DOMAIN, TAG, `AVPlayer videoScaleType set to FIT`);
                            // 动态调整XComponent尺寸
                            this.updateXComponentSize();
                        }
                        break;
                    case 'playing':
                        hilog.info(DOMAIN, TAG, 'AVPlayer state playing called.');
                        this.isPlaying = true;
                        break;
                    case 'paused':
                        hilog.info(DOMAIN, TAG, 'AVPlayer state paused called.');
                        this.isPlaying = false;
                        break;
                    case 'completed':
                        hilog.info(DOMAIN, TAG, 'AVPlayer state completed called.');
                        this.isPlaying = false;
                        this.currentPosition = 0;
                        break;
                    case 'stopped':
                        hilog.info(DOMAIN, TAG, 'AVPlayer state stopped called.');
                        this.isPlaying = false;
                        break;
                    case 'released':
                        hilog.info(DOMAIN, TAG, 'AVPlayer state released called.');
                        // 播放器已释放
                        break;
                    default:
                        hilog.info(DOMAIN, TAG, 'AVPlayer state unknown called.');
                        break;
                }
            });
            // 设置时间更新回调
            this.avPlayer.on('timeUpdate', (position: number) => {
                this.onTimeUpdate(position);
            });
            // 设置错误回调
            this.avPlayer.on('error', (error: BusinessError) => {
                this.isPlaying = false;
                this.errorMessage = `视频播放出错: ${error.code}, ${error.message}`;
                hilog.error(DOMAIN, TAG, `Player error: ${error.code}, ${error.message}`);
                this.avPlayer?.reset(); // 出错时重置播放器
            });
            // 设置首帧渲染回调
            this.avPlayer.on('startRenderFrame', () => {
                hilog.info(DOMAIN, TAG, 'AVPlayer start render frame');
                if (this.avPlayer) {
                    const currentWidth = this.avPlayer.width;
                    const currentHeight = this.avPlayer.height;
                    hilog.info(DOMAIN, TAG, `AVPlayer startRenderFrame - width: ${currentWidth}, height: ${currentHeight}`);
                    if (this.videoInfo && (this.videoInfo.width !== currentWidth || this.videoInfo.height !== currentHeight) && currentWidth > 0 && currentHeight > 0) {
                        this.videoInfo = {
                            duration: this.videoInfo.duration,
                            fps: this.videoInfo.fps,
                            width: currentWidth,
                            height: currentHeight
                        };
                        hilog.info(DOMAIN, TAG, `Video info updated on startRenderFrame: ${JSON.stringify(this.videoInfo)}`);
                    }
                    else if (!this.videoInfo && currentWidth > 0 && currentHeight > 0) {
                        // 如果videoInfo之前是null，并且现在获取到了有效宽高 (虽然prepared事件应该先初始化它)
                        this.videoInfo = {
                            duration: this.avPlayer.duration > 0 ? this.avPlayer.duration / 1000 : 0,
                            width: currentWidth,
                            height: currentHeight,
                            fps: undefined // 或者根据需要设置默认值
                        };
                        hilog.info(DOMAIN, TAG, `Video info initialized on startRenderFrame: ${JSON.stringify(this.videoInfo)}`);
                    }
                }
            });
            // 设置播放源
            this.avPlayer.url = `fd://${this.currentFd}`;
            hilog.info(DOMAIN, TAG, `Video player initialized with fd URI: fd://${this.currentFd}`);
        }
        catch (error) {
            this.errorMessage = `初始化视频播放器失败: ${error}`;
            hilog.error(DOMAIN, TAG, this.errorMessage);
        }
    }
    // XComponent的surfaceID，用于视频渲染
    private surfaceID: string;
    onTimeUpdate(time: number) {
        this.currentPosition = time / 1000;
    }
    async releaseResources() {
        // 释放视频播放器
        if (this.avPlayer) {
            try {
                await this.avPlayer.stop();
                await this.avPlayer.reset();
                await this.avPlayer.release();
                this.avPlayer = null;
            }
            catch (error) {
                hilog.error(DOMAIN, TAG, `Release video player error: ${error}`);
            }
        }
        // 关闭文件描述符
        if (this.currentFd !== -1) {
            try {
                await fs.close(this.currentFd);
                hilog.info(DOMAIN, TAG, `Closed video file fd: ${this.currentFd}`);
                this.currentFd = -1;
            }
            catch (error) {
                hilog.error(DOMAIN, TAG, `Error closing video file fd: ${error.message}`);
            }
        }
        // 释放PixelMap资源
        for (const result of this.analysisResults) {
            if (result.pixelMap) {
                try {
                    result.pixelMap.release();
                }
                catch (e) {
                    // 忽略释放错误
                }
            }
        }
        // 断开WebSocket
        this.webSocketService.disconnect();
    }
    formatTime(seconds: number): string {
        const min = Math.floor(seconds / 60);
        const sec = Math.floor(seconds % 60);
        return `${min.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
    }
    /**
     * 初始化WebSocket服务
     */
    private initWebSocketService() {
        // 连接成功回调
        this.webSocketService.onConnect(() => {
            this.isConnected = true;
            this.errorMessage = '';
        });
        // 断开连接回调
        this.webSocketService.onDisconnect(() => {
            this.isConnected = false;
            this.errorMessage = '与服务器的连接已断开';
        });
        // 错误回调
        this.webSocketService.onError((error: string) => {
            this.errorMessage = error;
        });
        // 帧识别结果回调
        this.webSocketService.onFrameResult((frameId: number, plates: PlateInfo[]) => {
            hilog.info(DOMAIN, TAG, `Received frame_result for frameId ${frameId} with ${plates.length} plates`);
            const resultIndex = this.analysisResults.findIndex(r => r.frameId === frameId);
            if (resultIndex >= 0) {
                const currentItem = this.analysisResults[resultIndex];
                const updatedItem: FrameAnalysisResult = {
                    frameId: currentItem.frameId,
                    timeUs: currentItem.timeUs,
                    timeFormatted: currentItem.timeFormatted,
                    pixelMap: currentItem.pixelMap,
                    imageInfo: currentItem.imageInfo,
                    plates: plates,
                    isAnalyzing: false
                };
                this.analysisResults.splice(resultIndex, 1, updatedItem);
                this.analysisResults = this.analysisResults.slice();
                if (this.isContinuousAnalysisMode) {
                    const pendingAnalysis = this.analysisResults.filter(r => r.isAnalyzing);
                    if (pendingAnalysis.length === 0) {
                        this.isExtractingFrames = false;
                        promptAction.showToast({
                            message: `已完成所有 ${this.analysisResults.length} 帧的分析`,
                            duration: 3000
                        });
                    }
                }
                else {
                    promptAction.showToast({
                        message: `帧分析完成: 检测到 ${plates.length} 个车牌`,
                        duration: 2000
                    });
                }
            }
        });
        // 连接到服务器
        this.webSocketService.connect();
    }
    /**
     * 提取并分析当前时间点的帧
     */
    async extractAndAnalyzeCurrentFrame() {
        if (!this.videoUri || !this.avPlayer) {
            promptAction.showToast({ message: '视频未准备好', duration: 2000 });
            return;
        }
        try {
            if (this.isPlaying && this.avPlayer) {
                this.avPlayer.pause();
            }
            const currentTimeUs = Math.floor(this.currentPosition * 1000000);
            const frameId = Date.now();
            promptAction.showToast({ message: '正在提取当前帧...', duration: 2000 });
            const newFrameResult: FrameAnalysisResult = {
                frameId: frameId,
                timeUs: currentTimeUs,
                timeFormatted: this.formatTime(this.currentPosition),
                pixelMap: null,
                imageInfo: null,
                plates: [],
                isAnalyzing: true
            };
            this.analysisResults.push(newFrameResult);
            this.analysisResults = this.analysisResults.slice();
            const resultIndex = this.analysisResults.length - 1;
            const frame = await this.videoService.getVideoFrameAtTime(this.videoUri, currentTimeUs);
            if (!frame) {
                const currentItem = this.analysisResults[resultIndex];
                const updatedItem: FrameAnalysisResult = {
                    frameId: currentItem.frameId,
                    timeUs: currentItem.timeUs,
                    timeFormatted: currentItem.timeFormatted,
                    pixelMap: currentItem.pixelMap,
                    imageInfo: currentItem.imageInfo,
                    plates: currentItem.plates,
                    isAnalyzing: false
                };
                this.analysisResults.splice(resultIndex, 1, updatedItem);
                this.analysisResults = this.analysisResults.slice();
                promptAction.showToast({ message: '提取帧失败', duration: 2000 });
                return;
            }
            const frameInfo = frame.getImageInfoSync();
            const currentItem = this.analysisResults[resultIndex];
            const updatedItemWithFrame: FrameAnalysisResult = {
                frameId: currentItem.frameId,
                timeUs: currentItem.timeUs,
                timeFormatted: currentItem.timeFormatted,
                pixelMap: frame,
                imageInfo: frameInfo,
                plates: currentItem.plates,
                isAnalyzing: currentItem.isAnalyzing
            };
            this.analysisResults.splice(resultIndex, 1, updatedItemWithFrame);
            this.analysisResults = this.analysisResults.slice();
            const frameBase64 = await this.videoService.convertPixelMapToBase64(frame);
            if (!frameBase64) {
                promptAction.showToast({ message: '帧转换为Base64失败', duration: 2000 });
                const currentItem = this.analysisResults[resultIndex];
                const failedItem: FrameAnalysisResult = {
                    frameId: currentItem.frameId,
                    timeUs: currentItem.timeUs,
                    timeFormatted: currentItem.timeFormatted,
                    pixelMap: currentItem.pixelMap,
                    imageInfo: currentItem.imageInfo,
                    plates: currentItem.plates,
                    isAnalyzing: false
                };
                this.analysisResults.splice(resultIndex, 1, failedItem);
                this.analysisResults = this.analysisResults.slice();
                return;
            }
            this.webSocketService.sendVideoFrameRequest(frameBase64, frameId);
            hilog.info(DOMAIN, TAG, `Frame extracted at ${currentTimeUs}us and sent for analysis with ID ${frameId}`);
        }
        catch (error) {
            promptAction.showToast({ message: `提取帧失败: ${error}`, duration: 3000 });
            hilog.error(DOMAIN, TAG, `Extract frame error: ${error}`);
        }
    }
    /**
     * 提取并分析多个帧（按时间间隔）
     */
    async extractAndAnalyzeMultipleFrames() {
        if (!this.videoUri || !this.videoInfo || this.videoInfo.duration <= 0) {
            promptAction.showToast({ message: '视频信息不完整', duration: 2000 });
            return;
        }
        try {
            const intervalSeconds = this.selectedInterval;
            const videoDurationSeconds = this.videoInfo.duration;
            const frameCount = Math.floor(videoDurationSeconds / intervalSeconds) + 1;
            if (frameCount > 10) {
                const confirmed = await promptAction.showDialog({
                    title: '确认批量分析',
                    message: `将提取并分析 ${frameCount} 帧视频内容，可能需要较长时间。是否继续？`,
                    buttons: [
                        { text: '取消', color: CommonConstants.SECONDARY_TEXT_COLOR },
                        { text: '继续', color: CommonConstants.PRIMARY_COLOR }
                    ]
                });
                if (confirmed.index !== 1) {
                    return;
                }
            }
            this.isExtractingFrames = true;
            this.isContinuousAnalysisMode = true;
            this.totalFramesToExtract = frameCount;
            this.analysisResults = [];
            for (let i = 0; i < frameCount; i++) {
                this.extractionProgress = Math.floor((i / frameCount) * 100);
                const currentTimeSeconds = i * intervalSeconds;
                const currentTimeUs = currentTimeSeconds * 1000000;
                const frameId = Date.now() + i;
                const newFrameResult: FrameAnalysisResult = {
                    frameId: frameId,
                    timeUs: currentTimeUs,
                    timeFormatted: this.formatTime(currentTimeSeconds),
                    pixelMap: null,
                    imageInfo: null,
                    plates: [],
                    isAnalyzing: true
                };
                this.analysisResults.push(newFrameResult);
                this.analysisResults = this.analysisResults.slice();
                const resultIndex = this.analysisResults.length - 1;
                const frame = await this.videoService.getVideoFrameAtTime(this.videoUri, currentTimeUs);
                if (!frame) {
                    const currentItem = this.analysisResults[resultIndex];
                    const updatedItem: FrameAnalysisResult = {
                        frameId: currentItem.frameId,
                        timeUs: currentItem.timeUs,
                        timeFormatted: currentItem.timeFormatted,
                        pixelMap: currentItem.pixelMap,
                        imageInfo: currentItem.imageInfo,
                        plates: currentItem.plates,
                        isAnalyzing: false
                    };
                    this.analysisResults.splice(resultIndex, 1, updatedItem);
                    this.analysisResults = this.analysisResults.slice();
                    continue;
                }
                const frameInfo = frame.getImageInfoSync();
                const currentItem = this.analysisResults[resultIndex];
                const updatedItemWithFrame: FrameAnalysisResult = {
                    frameId: currentItem.frameId,
                    timeUs: currentItem.timeUs,
                    timeFormatted: currentItem.timeFormatted,
                    pixelMap: frame,
                    imageInfo: frameInfo,
                    plates: currentItem.plates,
                    isAnalyzing: currentItem.isAnalyzing
                };
                this.analysisResults.splice(resultIndex, 1, updatedItemWithFrame);
                this.analysisResults = this.analysisResults.slice();
                const frameBase64 = await this.videoService.convertPixelMapToBase64(frame);
                if (!frameBase64) {
                    const currentItem = this.analysisResults[resultIndex];
                    const failedItem: FrameAnalysisResult = {
                        frameId: currentItem.frameId,
                        timeUs: currentItem.timeUs,
                        timeFormatted: currentItem.timeFormatted,
                        pixelMap: currentItem.pixelMap,
                        imageInfo: currentItem.imageInfo,
                        plates: currentItem.plates,
                        isAnalyzing: false
                    };
                    this.analysisResults.splice(resultIndex, 1, failedItem);
                    this.analysisResults = this.analysisResults.slice();
                    continue;
                }
                this.webSocketService.sendVideoFrameRequest(frameBase64, frameId);
                hilog.info(DOMAIN, TAG, `Batch frame ${i + 1}/${frameCount} extracted at ${currentTimeUs}us and sent for analysis with ID ${frameId}`);
            }
            this.extractionProgress = 100;
            promptAction.showToast({
                message: `成功提取 ${frameCount} 帧，正在等待分析结果`,
                duration: 3000
            });
        }
        catch (error) {
            this.isExtractingFrames = false;
            this.isContinuousAnalysisMode = false;
            promptAction.showToast({ message: `批量提取帧失败: ${error}`, duration: 3000 });
            hilog.error(DOMAIN, TAG, `Batch extract frames error: ${error}`);
        }
    }
    // 新增方法：更新XComponent的尺寸
    async updateXComponentSize() {
        if (!this.videoInfo || this.videoInfo.width <= 0 || this.videoInfo.height <= 0) {
            // 如果视频信息无效，则使用默认/初始尺寸
            this.xComponentWidth = '100%';
            this.xComponentHeight = 220; // 默认高度
            hilog.warn(DOMAIN, TAG, 'Video info not available or invalid for dynamic size, using default.');
            return;
        }
        try {
            const defaultDisplay = await display.getDefaultDisplay(); // 使用异步API
            const screenWidthPx = defaultDisplay.width;
            const screenHeightPx = defaultDisplay.height;
            const density = defaultDisplay.densityDPI / 160; // 计算密度
            // 将屏幕尺寸转换为vp (近似)
            const screenWidthVp = screenWidthPx / density;
            const screenHeightVp = screenHeightPx / density;
            // 假设页面左右内边距总和 (需要根据你的 CommonConstants.PAGE_PADDING 调整)
            // 例如，如果 PAGE_PADDING.left 和 PAGE_PADDING.right 都是 16vp
            const pageHorizontalPaddingVp = (CommonConstants.PAGE_PADDING as number || 0) * 2;
            const availableWidthVp = screenWidthVp - pageHorizontalPaddingVp;
            const videoAspectRatio = this.videoInfo.width / this.videoInfo.height;
            // 方案：宽度撑满可用区域，高度按比例计算
            let targetWidthVp = availableWidthVp;
            let targetHeightVp = targetWidthVp / videoAspectRatio;
            // 根据视频方向调整最大高度限制
            let maxComponentHeightVp: number;
            if (this.videoInfo.width < this.videoInfo.height) { // 竖屏视频
                maxComponentHeightVp = screenHeightVp * 0.40; // 竖屏视频最大高度限制为屏幕高度的40%
            }
            else { // 横屏或方形视频
                maxComponentHeightVp = screenHeightVp * 0.55; // 横屏/方形视频最大高度限制为屏幕高度的55%
            }
            // 如果计算出的高度超过最大限制，则调整高度和宽度
            if (targetHeightVp > maxComponentHeightVp) {
                targetHeightVp = maxComponentHeightVp;
                targetWidthVp = targetHeightVp * videoAspectRatio;
            }
            // 安全检查，确保计算出的宽高是有效数字且大于0
            if (isFinite(targetWidthVp) && targetWidthVp > 0 && isFinite(targetHeightVp) && targetHeightVp > 0) {
                this.xComponentWidth = targetWidthVp;
                this.xComponentHeight = targetHeightVp;
                hilog.info(DOMAIN, TAG, `XComponent dynamic size set to: ${targetWidthVp}vp x ${targetHeightVp}vp (video aspect: ${videoAspectRatio})`);
            }
            else {
                hilog.error(DOMAIN, TAG, `Calculated dynamic size is invalid. Width: ${targetWidthVp}, Height: ${targetHeightVp}. Using default.`);
                this.xComponentWidth = '100%';
                this.xComponentHeight = 220;
            }
        }
        catch (err) {
            hilog.error(DOMAIN, TAG, `Failed to get display info or set dynamic size: ${err.message}`);
            this.xComponentWidth = '100%';
            this.xComponentHeight = 220;
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(672:5)", "entry");
            Scroll.width('100%');
            Scroll.height('100%');
            Scroll.scrollable(ScrollDirection.Vertical);
            Scroll.scrollBar(BarState.Auto);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(673:7)", "entry");
            Column.width('100%');
            Column.backgroundColor(CommonConstants.BACKGROUND_COLOR);
            Column.padding(CommonConstants.PAGE_PADDING);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 标题栏
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(675:9)", "entry");
            // 标题栏
            Row.width('100%');
            // 标题栏
            Row.padding(CommonConstants.PAGE_PADDING);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithChild({ type: ButtonType.Normal });
            Button.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(676:11)", "entry");
            Button.backgroundColor(Color.Transparent);
            Button.onClick(() => {
                router.back();
            });
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 125830087, "type": 20000, params: [], "bundleName": "com.example.yolo1", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(677:13)", "entry");
            Image.width(24);
            Image.height(24);
        }, Image);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('视频分析');
            Text.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(686:11)", "entry");
            Text.fontSize(CommonConstants.TITLE_FONT_SIZE);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(CommonConstants.TEXT_COLOR);
            Text.margin({ left: 12 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(692:11)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.isConnected ? '已连接' : '未连接');
            Text.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(694:11)", "entry");
            Text.fontSize(CommonConstants.SMALL_FONT_SIZE);
            Text.fontColor(this.isConnected ? CommonConstants.SUCCESS_COLOR : CommonConstants.ERROR_COLOR);
        }, Text);
        Text.pop();
        // 标题栏
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // 错误信息
            if (this.errorMessage) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.errorMessage);
                        Text.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(703:11)", "entry");
                        Text.fontSize(CommonConstants.SMALL_FONT_SIZE);
                        Text.fontColor(CommonConstants.ERROR_COLOR);
                        Text.width('100%');
                        Text.textAlign(TextAlign.Center);
                        Text.padding(CommonConstants.PAGE_PADDING);
                        Text.backgroundColor('#FFEBEE');
                        Text.margin({ bottom: CommonConstants.COMPONENT_SPACING });
                    }, Text);
                    Text.pop();
                });
            }
            // 视频播放区域
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // 视频播放区域
            if (this.videoUri) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Stack.create();
                        Stack.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(715:11)", "entry");
                        Stack.width('100%');
                        Stack.margin({ bottom: CommonConstants.COMPONENT_SPACING });
                    }, Stack);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        XComponent.create({
                            id: 'videoPlayer',
                            type: 'surface',
                            controller: this.xcomponentController
                        }, "com.example.yolo1/entry");
                        XComponent.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(716:13)", "entry");
                        XComponent.width(this.xComponentWidth);
                        XComponent.height(this.xComponentHeight);
                        XComponent.backgroundColor(Color.Black);
                        XComponent.onAppear(() => {
                            hilog.info(DOMAIN, TAG, 'XComponent onAppear triggered');
                            // 尝试在 onAppear 中通过 controller 获取 surfaceId
                            try {
                                const surfaceIdFromController = this.xcomponentController.getXComponentSurfaceId();
                                hilog.info(DOMAIN, TAG, `XComponent onAppear, surfaceId from controller: ${surfaceIdFromController}`);
                                if (surfaceIdFromController) {
                                    this.surfaceID = surfaceIdFromController; // 更新我们自己维护的 surfaceID 状态
                                    if (this.avPlayer) {
                                        // 只有当播放器的 surfaceId 与新获取的不同时，才进行赋值
                                        if (this.avPlayer.surfaceId !== this.surfaceID) {
                                            this.avPlayer.surfaceId = this.surfaceID;
                                            hilog.info(DOMAIN, TAG, `[XComponent.onAppear] Set avPlayer.surfaceId to ${this.surfaceID}.`);
                                        }
                                        // 根据播放器当前状态决定是否需要触发操作
                                        // 如果播放器已是 initialized 状态并且 surfaceId 已有效设置，则调用 prepare
                                        if (this.avPlayer.state === 'initialized' && this.avPlayer.surfaceId) {
                                            hilog.info(DOMAIN, TAG, '[XComponent.onAppear] Player is "initialized" and surfaceId is set. Calling prepare().');
                                            this.avPlayer.prepare();
                                        }
                                        else if (this.avPlayer.state === 'idle' && this.currentFd !== -1) {
                                            hilog.info(DOMAIN, TAG, '[XComponent.onAppear] Player is "idle" and fd is valid. Setting URL to ensure transition to "initialized".');
                                            // 设置URL会触发播放器进入 initialized 状态，届时 initialized 状态回调会处理 prepare
                                            this.avPlayer.url = `fd://${this.currentFd}`;
                                        }
                                        else {
                                            hilog.info(DOMAIN, TAG, `[XComponent.onAppear] Player state is '${this.avPlayer.state}'. surfaceId is '${this.avPlayer.surfaceId}'. No immediate prepare action here.`);
                                        }
                                    }
                                    else {
                                        // avPlayer 实例此时可能还未被 initVideoPlayer 创建完毕
                                        // this.surfaceID (页面变量) 已保存，initVideoPlayer 中的 'initialized' 状态回调应能获取并使用它
                                        hilog.warn(DOMAIN, TAG, '[XComponent.onAppear] avPlayer instance not available yet. Stored surfaceID for initVideoPlayer.');
                                    }
                                }
                                else {
                                    hilog.warn(DOMAIN, TAG, 'XComponent onAppear, surfaceId from controller is null or empty.');
                                }
                            }
                            catch (e) {
                                hilog.error(DOMAIN, TAG, `Error getting surfaceId from controller in onAppear: ${e.message}`);
                            }
                        });
                        XComponent.onLoad((context: object) => {
                            // 获取XComponent的surfaceID - 保留原有onLoad逻辑作为备用或观察，但主要逻辑移到onAppear
                            hilog.info(DOMAIN, TAG, 'XComponent onLoad triggered (will primarily use onAppear for surfaceId)');
                            if (context) {
                                const surfaceIdFromContext = (context as XComponentContext).getXComponentSurfaceId();
                                hilog.info(DOMAIN, TAG, `XComponent onLoad, surfaceID from context: ${surfaceIdFromContext}`);
                                // 如果 onAppear 没有成功，但 onLoad 成功了，可以考虑在这里也尝试处理
                                // 但为了避免逻辑冲突，当前主要依赖 onAppear 通过 controller 获取
                                if (surfaceIdFromContext && !this.surfaceID) { // 仅当 onAppear 未成功设置 surfaceID 时
                                    this.surfaceID = surfaceIdFromContext;
                                    // ... (可以复制 onAppear 中的播放器处理逻辑，但要注意避免重复执行)
                                    hilog.warn(DOMAIN, TAG, 'SurfaceID obtained from onLoad context as onAppear might not have succeeded.');
                                }
                            }
                        });
                    }, XComponent);
                    Stack.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 视频控制器
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(785:11)", "entry");
                        // 视频控制器
                        Column.padding({ left: 16, right: 16 });
                        // 视频控制器
                        Column.width('100%');
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 播放进度条
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(787:13)", "entry");
                        // 播放进度条
                        Row.width('100%');
                        // 播放进度条
                        Row.margin({ bottom: 8 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.formatTime(this.currentPosition));
                        Text.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(788:15)", "entry");
                        Text.fontSize(12);
                        Text.fontColor(CommonConstants.SECONDARY_TEXT_COLOR);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Slider.create({
                            value: this.currentPosition,
                            min: 0,
                            max: this.videoInfo?.duration || 100,
                            step: 1
                        });
                        Slider.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(792:15)", "entry");
                        Slider.layoutWeight(1);
                        Slider.margin({ left: 8, right: 8 });
                        Slider.onChange((value: number) => {
                            if (this.avPlayer) {
                                this.avPlayer.seek(value * 1000);
                            }
                        });
                    }, Slider);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.formatTime(this.videoInfo?.duration || 0));
                        Text.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(806:15)", "entry");
                        Text.fontSize(12);
                        Text.fontColor(CommonConstants.SECONDARY_TEXT_COLOR);
                    }, Text);
                    Text.pop();
                    // 播放进度条
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 播放控制按钮
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(814:13)", "entry");
                        // 播放控制按钮
                        Row.width('100%');
                        // 播放控制按钮
                        Row.justifyContent(FlexAlign.Center);
                        // 播放控制按钮
                        Row.margin({ bottom: 16 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithChild({ type: ButtonType.Normal });
                        Button.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(815:15)", "entry");
                        Button.backgroundColor(Color.Transparent);
                        Button.margin({ right: 16 });
                        Button.onClick(() => {
                            if (!this.avPlayer)
                                return;
                            if (this.isPlaying) {
                                this.avPlayer.pause();
                            }
                            else {
                                this.avPlayer.play();
                            }
                        });
                    }, Button);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create(this.isPlaying ? { "id": 125830396, "type": 20000, params: [], "bundleName": "com.example.yolo1", "moduleName": "entry" } : { "id": 125830399, "type": 20000, params: [], "bundleName": "com.example.yolo1", "moduleName": "entry" });
                        Image.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(816:17)", "entry");
                        Image.width(24);
                        Image.height(24);
                    }, Image);
                    Button.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('提取当前帧');
                        Button.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(832:15)", "entry");
                        Button.height(CommonConstants.BUTTON_HEIGHT);
                        Button.backgroundColor(CommonConstants.PRIMARY_COLOR);
                        Button.fontColor(Color.White);
                        Button.fontSize(CommonConstants.SMALL_FONT_SIZE);
                        Button.enabled(!this.isExtractingFrames && this.isConnected);
                        Button.onClick(() => {
                            this.extractAndAnalyzeCurrentFrame();
                        });
                    }, Button);
                    Button.pop();
                    // 播放控制按钮
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 批量提取控制
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(847:13)", "entry");
                        // 批量提取控制
                        Row.width('100%');
                        // 批量提取控制
                        Row.margin({ bottom: 16 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('提取间隔:');
                        Text.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(848:15)", "entry");
                        Text.fontSize(CommonConstants.SMALL_FONT_SIZE);
                        Text.fontColor(CommonConstants.TEXT_COLOR);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Select.create([
                            { value: ExtractionInterval.ONE_SECOND.toString() },
                            { value: ExtractionInterval.THREE_SECONDS.toString() },
                            { value: ExtractionInterval.FIVE_SECONDS.toString() },
                            { value: ExtractionInterval.TEN_SECONDS.toString() }
                        ]);
                        Select.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(852:15)", "entry");
                        Select.value(this.selectedInterval.toString());
                        Select.font({ size: CommonConstants.SMALL_FONT_SIZE });
                        Select.margin({ left: 8, right: 16 });
                        Select.onSelect((index: number, selectedValue?: string) => {
                            if (selectedValue !== undefined) {
                                this.selectedInterval = parseInt(selectedValue) as ExtractionInterval;
                            }
                        });
                    }, Select);
                    Select.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('批量提取分析');
                        Button.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(867:15)", "entry");
                        Button.height(CommonConstants.BUTTON_HEIGHT);
                        Button.backgroundColor(CommonConstants.SUCCESS_COLOR);
                        Button.fontColor(Color.White);
                        Button.fontSize(CommonConstants.SMALL_FONT_SIZE);
                        Button.enabled(!this.isExtractingFrames && this.isConnected);
                        Button.onClick(() => {
                            this.extractAndAnalyzeMultipleFrames();
                        });
                    }, Button);
                    Button.pop();
                    // 批量提取控制
                    Row.pop();
                    // 视频控制器
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // ---Begin: Scrollable bottom part (Results, etc.) ---
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(884:11)", "entry");
                        // ---Begin: Scrollable bottom part (Results, etc.) ---
                        Column.width('100%');
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        // 批量提取进度
                        if (this.isExtractingFrames) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Row.create();
                                    Row.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(887:15)", "entry");
                                    Row.width('100%');
                                    Row.justifyContent(FlexAlign.Center);
                                    Row.margin({ bottom: 16 });
                                }, Row);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Progress.create({ value: this.extractionProgress, total: 100 });
                                    Progress.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(888:17)", "entry");
                                    Progress.width('80%');
                                    Progress.color(CommonConstants.PRIMARY_COLOR);
                                }, Progress);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create(`${this.extractionProgress}%`);
                                    Text.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(892:17)", "entry");
                                    Text.fontSize(12);
                                    Text.fontColor(CommonConstants.SECONDARY_TEXT_COLOR);
                                    Text.margin({ left: 8 });
                                }, Text);
                                Text.pop();
                                Row.pop();
                            });
                        }
                        // 分隔线
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 分隔线
                        Divider.create();
                        Divider.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(903:13)", "entry");
                        // 分隔线
                        Divider.width('100%');
                        // 分隔线
                        Divider.color('#E0E0E0');
                        // 分隔线
                        Divider.margin({ bottom: 16 });
                    }, Divider);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        // 分析结果标题
                        if (this.analysisResults.length > 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create(`识别结果 (${this.analysisResults.length}帧)`);
                                    Text.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(910:15)", "entry");
                                    Text.fontSize(CommonConstants.SUBTITLE_FONT_SIZE);
                                    Text.fontWeight(FontWeight.Bold);
                                    Text.fontColor(CommonConstants.TEXT_COLOR);
                                    Text.margin({ bottom: 12 });
                                }, Text);
                                Text.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('尚未提取任何帧');
                                    Text.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(916:15)", "entry");
                                    Text.fontSize(CommonConstants.BODY_FONT_SIZE);
                                    Text.fontColor(CommonConstants.SECONDARY_TEXT_COLOR);
                                    Text.margin({ bottom: 12 });
                                }, Text);
                                Text.pop();
                            });
                        }
                    }, If);
                    If.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 显示帧缩略图列表
                        Grid.create();
                        Grid.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(923:13)", "entry");
                        // 显示帧缩略图列表
                        Grid.columnsTemplate('1fr 1fr 1fr');
                        // 显示帧缩略图列表
                        Grid.columnsGap(8);
                        // 显示帧缩略图列表
                        Grid.rowsGap(8);
                        // 显示帧缩略图列表
                        Grid.margin({ bottom: 16 });
                    }, Grid);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = (_item, index?: number) => {
                            const result = _item;
                            {
                                const itemCreation2 = (elmtId, isInitialRender) => {
                                    GridItem.create(() => { }, false);
                                    GridItem.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(925:17)", "entry");
                                };
                                const observedDeepRender = () => {
                                    this.observeComponentCreation2(itemCreation2, GridItem);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Column.create();
                                        Column.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(926:19)", "entry");
                                        Column.width('100%');
                                        Column.height(110);
                                        Column.backgroundColor(this.selectedFrameIndex === index ? '#E3F2FD' : Color.White);
                                        Column.borderRadius(8);
                                        Column.padding(4);
                                        Column.onClick(() => {
                                            this.selectedFrameIndex = index !== undefined ? index : -1;
                                        });
                                    }, Column);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Stack.create();
                                        Stack.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(927:21)", "entry");
                                        Stack.width('100%');
                                        Stack.height(80);
                                    }, Stack);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        If.create();
                                        if (result.pixelMap) {
                                            this.ifElseBranchUpdateFunction(0, () => {
                                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                    Image.create(result.pixelMap);
                                                    Image.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(929:25)", "entry");
                                                    Image.width('100%');
                                                    Image.height(80);
                                                    Image.objectFit(ImageFit.Cover);
                                                    Image.borderRadius(4);
                                                    Image.backgroundColor(CommonConstants.CARD_BACKGROUND_COLOR);
                                                }, Image);
                                            });
                                        }
                                        else {
                                            this.ifElseBranchUpdateFunction(1, () => {
                                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                    Text.create('提取中...');
                                                    Text.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(936:25)", "entry");
                                                    Text.width('100%');
                                                    Text.height(80);
                                                    Text.textAlign(TextAlign.Center);
                                                    Text.backgroundColor(CommonConstants.CARD_BACKGROUND_COLOR);
                                                    Text.borderRadius(4);
                                                }, Text);
                                                Text.pop();
                                            });
                                        }
                                    }, If);
                                    If.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        If.create();
                                        if (result.isAnalyzing) {
                                            this.ifElseBranchUpdateFunction(0, () => {
                                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                    LoadingProgress.create();
                                                    LoadingProgress.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(945:25)", "entry");
                                                    LoadingProgress.width(24);
                                                    LoadingProgress.height(24);
                                                    LoadingProgress.color(CommonConstants.PRIMARY_COLOR);
                                                }, LoadingProgress);
                                            });
                                        }
                                        // 车牌数量标记
                                        else {
                                            this.ifElseBranchUpdateFunction(1, () => {
                                            });
                                        }
                                    }, If);
                                    If.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        If.create();
                                        // 车牌数量标记
                                        if (result.plates.length > 0 && !result.isAnalyzing) {
                                            this.ifElseBranchUpdateFunction(0, () => {
                                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                    Badge.create({
                                                        count: result.plates.length,
                                                        position: BadgePosition.RightTop,
                                                        style: { color: Color.White, badgeSize: 18, badgeColor: CommonConstants.SUCCESS_COLOR }
                                                    });
                                                    Badge.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(953:25)", "entry");
                                                }, Badge);
                                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                    Column.create();
                                                    Column.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(958:27)", "entry");
                                                    Column.width('100%');
                                                    Column.height('100%');
                                                }, Column);
                                                Column.pop();
                                                Badge.pop();
                                            });
                                        }
                                        else {
                                            this.ifElseBranchUpdateFunction(1, () => {
                                            });
                                        }
                                    }, If);
                                    If.pop();
                                    Stack.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Text.create(result.timeFormatted);
                                        Text.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(967:21)", "entry");
                                        Text.fontSize(12);
                                        Text.fontColor(CommonConstants.SECONDARY_TEXT_COLOR);
                                        Text.margin({ top: 4 });
                                    }, Text);
                                    Text.pop();
                                    Column.pop();
                                    GridItem.pop();
                                };
                                observedDeepRender();
                            }
                        };
                        this.forEachUpdateFunction(elmtId, this.analysisResults, forEachItemGenFunction, undefined, true, false);
                    }, ForEach);
                    ForEach.pop();
                    // 显示帧缩略图列表
                    Grid.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        // 所选帧的详细结果 (内部已有 Scroll)
                        if (this.selectedFrameIndex >= 0 && this.selectedFrameIndex < this.analysisResults.length) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Scroll.create();
                                    Scroll.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(990:15)", "entry");
                                    Scroll.width('100%');
                                    Scroll.margin({ bottom: CommonConstants.COMPONENT_SPACING });
                                }, Scroll);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Column.create();
                                    Column.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(991:17)", "entry");
                                    Column.width('100%');
                                    Column.padding(16);
                                    Column.backgroundColor('#F5F5F5');
                                    Column.borderRadius(8);
                                }, Column);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create(`时间点: ${this.analysisResults[this.selectedFrameIndex].timeFormatted}`);
                                    Text.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(992:19)", "entry");
                                    Text.fontSize(CommonConstants.BODY_FONT_SIZE);
                                    Text.fontWeight(FontWeight.Medium);
                                    Text.fontColor(CommonConstants.TEXT_COLOR);
                                    Text.margin({ bottom: 8 });
                                }, Text);
                                Text.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    If.create();
                                    if (this.analysisResults[this.selectedFrameIndex].pixelMap && this.analysisResults[this.selectedFrameIndex].imageInfo) {
                                        this.ifElseBranchUpdateFunction(0, () => {
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                Stack.create();
                                                Stack.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(999:21)", "entry");
                                                Stack.width('100%');
                                                Stack.height(200);
                                                Stack.margin({ bottom: 12 });
                                            }, Stack);
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                Image.create(this.analysisResults[this.selectedFrameIndex].pixelMap);
                                                Image.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(1000:23)", "entry");
                                                Image.width('100%');
                                                Image.height(200);
                                                Image.objectFit(ImageFit.Contain);
                                                Image.backgroundColor(CommonConstants.CARD_BACKGROUND_COLOR);
                                            }, Image);
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                __Common__.create();
                                                __Common__.width('100%');
                                            }, __Common__);
                                            {
                                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                    if (isInitialRender) {
                                                        let componentCall = new 
                                                        // 绘制车牌标注
                                                        PlateAnnotatorCanvas(this, {
                                                            pixelMap: this.analysisResults[this.selectedFrameIndex].pixelMap,
                                                            plates: this.analysisResults[this.selectedFrameIndex].plates,
                                                            canvasDisplayHeight: 200,
                                                            imageInfo: this.analysisResults[this.selectedFrameIndex].imageInfo
                                                        }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/VideoAnalysisPage.ets", line: 1007, col: 23 });
                                                        ViewPU.create(componentCall);
                                                        let paramsLambda = () => {
                                                            return {
                                                                pixelMap: this.analysisResults[this.selectedFrameIndex].pixelMap,
                                                                plates: this.analysisResults[this.selectedFrameIndex].plates,
                                                                canvasDisplayHeight: 200,
                                                                imageInfo: this.analysisResults[this.selectedFrameIndex].imageInfo
                                                            };
                                                        };
                                                        componentCall.paramsGenerator_ = paramsLambda;
                                                    }
                                                    else {
                                                        this.updateStateVarsOfChildByElmtId(elmtId, {
                                                            pixelMap: this.analysisResults[this.selectedFrameIndex].pixelMap,
                                                            plates: this.analysisResults[this.selectedFrameIndex].plates,
                                                            canvasDisplayHeight: 200,
                                                            imageInfo: this.analysisResults[this.selectedFrameIndex].imageInfo
                                                        });
                                                    }
                                                }, { name: "PlateAnnotatorCanvas" });
                                            }
                                            __Common__.pop();
                                            Stack.pop();
                                        });
                                    }
                                    else {
                                        this.ifElseBranchUpdateFunction(1, () => {
                                        });
                                    }
                                }, If);
                                If.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    If.create();
                                    if (this.analysisResults[this.selectedFrameIndex].isAnalyzing) {
                                        this.ifElseBranchUpdateFunction(0, () => {
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                Row.create();
                                                Row.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(1021:21)", "entry");
                                                Row.margin({ bottom: 12 });
                                            }, Row);
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                LoadingProgress.create();
                                                LoadingProgress.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(1022:23)", "entry");
                                                LoadingProgress.width(24);
                                                LoadingProgress.height(24);
                                                LoadingProgress.color(CommonConstants.PRIMARY_COLOR);
                                            }, LoadingProgress);
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                Text.create('正在分析中...');
                                                Text.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(1027:23)", "entry");
                                                Text.fontSize(CommonConstants.BODY_FONT_SIZE);
                                                Text.fontColor(CommonConstants.SECONDARY_TEXT_COLOR);
                                                Text.margin({ left: 8 });
                                            }, Text);
                                            Text.pop();
                                            Row.pop();
                                        });
                                    }
                                    else if (this.analysisResults[this.selectedFrameIndex].plates.length > 0) {
                                        this.ifElseBranchUpdateFunction(1, () => {
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                Text.create(`识别结果 (${this.analysisResults[this.selectedFrameIndex].plates.length}个车牌)`);
                                                Text.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(1034:21)", "entry");
                                                Text.fontSize(CommonConstants.BODY_FONT_SIZE);
                                                Text.fontWeight(FontWeight.Medium);
                                                Text.margin({ bottom: 8 });
                                            }, Text);
                                            Text.pop();
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                List.create();
                                                List.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(1039:21)", "entry");
                                                List.width('100%');
                                            }, List);
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                ForEach.create();
                                                const forEachItemGenFunction = _item => {
                                                    const plate = _item;
                                                    {
                                                        const itemCreation = (elmtId, isInitialRender) => {
                                                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                                            itemCreation2(elmtId, isInitialRender);
                                                            if (!isInitialRender) {
                                                                ListItem.pop();
                                                            }
                                                            ViewStackProcessor.StopGetAccessRecording();
                                                        };
                                                        const itemCreation2 = (elmtId, isInitialRender) => {
                                                            ListItem.create(deepRenderFunction, true);
                                                            ListItem.margin({ bottom: 8 });
                                                            ListItem.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(1041:25)", "entry");
                                                        };
                                                        const deepRenderFunction = (elmtId, isInitialRender) => {
                                                            itemCreation(elmtId, isInitialRender);
                                                            {
                                                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                                    if (isInitialRender) {
                                                                        let componentCall = new PlateResultItem(this, { plateInfo: plate }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/VideoAnalysisPage.ets", line: 1042, col: 27 });
                                                                        ViewPU.create(componentCall);
                                                                        let paramsLambda = () => {
                                                                            return {
                                                                                plateInfo: plate
                                                                            };
                                                                        };
                                                                        componentCall.paramsGenerator_ = paramsLambda;
                                                                    }
                                                                    else {
                                                                        this.updateStateVarsOfChildByElmtId(elmtId, {});
                                                                    }
                                                                }, { name: "PlateResultItem" });
                                                            }
                                                            ListItem.pop();
                                                        };
                                                        this.observeComponentCreation2(itemCreation2, ListItem);
                                                        ListItem.pop();
                                                    }
                                                };
                                                this.forEachUpdateFunction(elmtId, this.analysisResults[this.selectedFrameIndex].plates, forEachItemGenFunction);
                                            }, ForEach);
                                            ForEach.pop();
                                            List.pop();
                                        });
                                    }
                                    else {
                                        this.ifElseBranchUpdateFunction(2, () => {
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                Text.create('未检测到车牌');
                                                Text.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(1049:21)", "entry");
                                                Text.fontSize(CommonConstants.BODY_FONT_SIZE);
                                                Text.fontColor(CommonConstants.SECONDARY_TEXT_COLOR);
                                            }, Text);
                                            Text.pop();
                                        });
                                    }
                                }, If);
                                If.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    If.create();
                                    // 跳转到此帧按钮
                                    if (this.avPlayer && this.selectedFrameIndex >= 0 && !this.analysisResults[this.selectedFrameIndex].isAnalyzing) {
                                        this.ifElseBranchUpdateFunction(0, () => {
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                Button.createWithLabel('跳转到此时间点');
                                                Button.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(1056:21)", "entry");
                                                Button.height(CommonConstants.BUTTON_HEIGHT);
                                                Button.backgroundColor(CommonConstants.PRIMARY_COLOR);
                                                Button.fontColor(Color.White);
                                                Button.fontSize(CommonConstants.BODY_FONT_SIZE);
                                                Button.width('100%');
                                                Button.margin({ top: 16 });
                                                Button.onClick(() => {
                                                    if (this.avPlayer && this.selectedFrameIndex >= 0) {
                                                        this.avPlayer.seek(this.analysisResults[this.selectedFrameIndex].timeUs / 1000);
                                                    }
                                                });
                                            }, Button);
                                            Button.pop();
                                        });
                                    }
                                    else {
                                        this.ifElseBranchUpdateFunction(1, () => {
                                        });
                                    }
                                }, If);
                                If.pop();
                                Column.pop();
                                Scroll.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    // ---Begin: Scrollable bottom part (Results, etc.) ---
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        // 视频加载中提示
                        if (this.isLoading) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Column.create();
                                    Column.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(1084:13)", "entry");
                                    Column.width('100%');
                                    Column.height(300);
                                    Column.justifyContent(FlexAlign.Center);
                                }, Column);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    LoadingProgress.create();
                                    LoadingProgress.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(1085:15)", "entry");
                                    LoadingProgress.width(40);
                                    LoadingProgress.height(40);
                                    LoadingProgress.color(CommonConstants.PRIMARY_COLOR);
                                }, LoadingProgress);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('正在加载视频...');
                                    Text.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(1090:15)", "entry");
                                    Text.fontSize(CommonConstants.BODY_FONT_SIZE);
                                    Text.fontColor(CommonConstants.SECONDARY_TEXT_COLOR);
                                    Text.margin({ top: 16 });
                                }, Text);
                                Text.pop();
                                Column.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Column.create();
                                    Column.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(1099:13)", "entry");
                                    Column.width('100%');
                                    Column.height(300);
                                    Column.justifyContent(FlexAlign.Center);
                                }, Column);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('未选择视频或视频无效');
                                    Text.debugLine("entry/src/main/ets/pages/VideoAnalysisPage.ets(1100:15)", "entry");
                                    Text.fontSize(CommonConstants.BODY_FONT_SIZE);
                                    Text.fontColor(CommonConstants.SECONDARY_TEXT_COLOR);
                                }, Text);
                                Text.pop();
                                Column.pop();
                            });
                        }
                    }, If);
                    If.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
        Scroll.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "VideoAnalysisPage";
    }
}
registerNamedRoute(() => new VideoAnalysisPage(undefined, {}), "", { bundleName: "com.example.yolo1", moduleName: "entry", pagePath: "pages/VideoAnalysisPage", pageFullPath: "entry/src/main/ets/pages/VideoAnalysisPage", integratedHsp: "false", moduleType: "followWithHap" });
