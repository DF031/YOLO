if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Index_Params {
    isConnected?: boolean;
    isLoading?: boolean;
    errorMessage?: string;
    imagePath?: string;
    recognizedPlates?: PlateInfo[];
    selectedPixelMap?: image.PixelMap | null;
    selectedImageInfo?: image.ImageInfo | null;
    webSocketService?: WebSocketService;
    networkService?: NetworkService;
    imageService?: ImageService;
    videoService?: VideoService;
}
import hilog from "@ohos:hilog";
import promptAction from "@ohos:promptAction";
import { WebSocketService } from "@normalized:N&&&entry/src/main/ets/services/WebSocketService&";
import { NetworkService } from "@normalized:N&&&entry/src/main/ets/services/NetworkService&";
import { ImageService } from "@normalized:N&&&entry/src/main/ets/services/ImageService&";
import { VideoService } from "@normalized:N&&&entry/src/main/ets/services/VideoService&";
import type { PlateInfo } from '../model/MessageTypes';
import { CommonConstants } from "@normalized:N&&&entry/src/main/ets/common/constants/CommonConstants&";
import { PlateResultItem } from "@normalized:N&&&entry/src/main/ets/components/PlateResultItem&";
import router from "@ohos:router";
import type image from "@ohos:multimedia.image";
import { PlateAnnotatorCanvas } from "@normalized:N&&&entry/src/main/ets/components/PlateAnnotatorCanvas&";
const DOMAIN = 0x0000;
const TAG = 'Index';
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__isConnected = new ObservedPropertySimplePU(false, this, "isConnected");
        this.__isLoading = new ObservedPropertySimplePU(false, this, "isLoading");
        this.__errorMessage = new ObservedPropertySimplePU('', this, "errorMessage");
        this.__imagePath = new ObservedPropertySimplePU('', this, "imagePath");
        this.__recognizedPlates = new ObservedPropertyObjectPU([], this, "recognizedPlates");
        this.__selectedPixelMap = new ObservedPropertyObjectPU(null, this, "selectedPixelMap");
        this.__selectedImageInfo = new ObservedPropertyObjectPU(null, this, "selectedImageInfo");
        this.webSocketService = new WebSocketService();
        this.networkService = new NetworkService();
        this.imageService = new ImageService();
        this.videoService = new VideoService();
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Index_Params) {
        if (params.isConnected !== undefined) {
            this.isConnected = params.isConnected;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
        if (params.errorMessage !== undefined) {
            this.errorMessage = params.errorMessage;
        }
        if (params.imagePath !== undefined) {
            this.imagePath = params.imagePath;
        }
        if (params.recognizedPlates !== undefined) {
            this.recognizedPlates = params.recognizedPlates;
        }
        if (params.selectedPixelMap !== undefined) {
            this.selectedPixelMap = params.selectedPixelMap;
        }
        if (params.selectedImageInfo !== undefined) {
            this.selectedImageInfo = params.selectedImageInfo;
        }
        if (params.webSocketService !== undefined) {
            this.webSocketService = params.webSocketService;
        }
        if (params.networkService !== undefined) {
            this.networkService = params.networkService;
        }
        if (params.imageService !== undefined) {
            this.imageService = params.imageService;
        }
        if (params.videoService !== undefined) {
            this.videoService = params.videoService;
        }
    }
    updateStateVars(params: Index_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__isConnected.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__errorMessage.purgeDependencyOnElmtId(rmElmtId);
        this.__imagePath.purgeDependencyOnElmtId(rmElmtId);
        this.__recognizedPlates.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedPixelMap.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedImageInfo.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__isConnected.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        this.__errorMessage.aboutToBeDeleted();
        this.__imagePath.aboutToBeDeleted();
        this.__recognizedPlates.aboutToBeDeleted();
        this.__selectedPixelMap.aboutToBeDeleted();
        this.__selectedImageInfo.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __isConnected: ObservedPropertySimplePU<boolean>;
    get isConnected() {
        return this.__isConnected.get();
    }
    set isConnected(newValue: boolean) {
        this.__isConnected.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    private __errorMessage: ObservedPropertySimplePU<string>;
    get errorMessage() {
        return this.__errorMessage.get();
    }
    set errorMessage(newValue: string) {
        this.__errorMessage.set(newValue);
    }
    private __imagePath: ObservedPropertySimplePU<string>;
    get imagePath() {
        return this.__imagePath.get();
    }
    set imagePath(newValue: string) {
        this.__imagePath.set(newValue);
    }
    private __recognizedPlates: ObservedPropertyObjectPU<PlateInfo[]>;
    get recognizedPlates() {
        return this.__recognizedPlates.get();
    }
    set recognizedPlates(newValue: PlateInfo[]) {
        this.__recognizedPlates.set(newValue);
    }
    private __selectedPixelMap: ObservedPropertyObjectPU<image.PixelMap | null>;
    get selectedPixelMap() {
        return this.__selectedPixelMap.get();
    }
    set selectedPixelMap(newValue: image.PixelMap | null) {
        this.__selectedPixelMap.set(newValue);
    }
    private __selectedImageInfo: ObservedPropertyObjectPU<image.ImageInfo | null>;
    get selectedImageInfo() {
        return this.__selectedImageInfo.get();
    }
    set selectedImageInfo(newValue: image.ImageInfo | null) {
        this.__selectedImageInfo.set(newValue);
    }
    private webSocketService: WebSocketService;
    private networkService: NetworkService;
    private imageService: ImageService;
    private videoService: VideoService;
    aboutToAppear() {
        // 初始化网络监控
        this.networkService.init();
        this.networkService.onNetworkChange((available: boolean) => {
            hilog.info(DOMAIN, TAG, `Network state changed: ${available ? 'available' : 'unavailable'}`);
            if (available) {
                // 网络可用时尝试连接WebSocket
                this.connectWebSocket();
            }
            else {
                // 网络不可用时显示错误信息
                this.isConnected = false;
                this.errorMessage = '网络不可用，请检查网络连接';
            }
        });
        // 初始化WebSocket服务
        this.initWebSocketService();
        // 如果网络可用，连接WebSocket
        if (this.networkService.isNetworkAvailable()) {
            this.connectWebSocket();
        }
    }
    aboutToDisappear() {
        // 断开WebSocket连接
        this.webSocketService.disconnect();
        // 释放网络监控资源
        this.networkService.release();
    }
    /**
     * 初始化WebSocket服务
     */
    private initWebSocketService() {
        // 连接成功回调
        this.webSocketService.onConnect(() => {
            this.isConnected = true;
            this.errorMessage = '';
        });
        // 断开连接回调
        this.webSocketService.onDisconnect(() => {
            this.isConnected = false;
            this.errorMessage = '与服务器的连接已断开';
        });
        // 错误回调
        this.webSocketService.onError((error: string) => {
            this.errorMessage = error;
        });
        // 车牌识别结果回调
        this.webSocketService.onPlateResult((plates: PlateInfo[]) => {
            this.isLoading = false;
            hilog.info(DOMAIN, TAG, `Received plates from WebSocketService (image): ${JSON.stringify(plates)}`);
            if (plates && plates.length > 0) {
                plates.forEach((p, index) => {
                    hilog.info(DOMAIN, TAG, `Plate ${index}: text=${p.text}, confidence=${p.confidence}, box=${JSON.stringify(p.box)}`);
                });
            }
            else {
                hilog.info(DOMAIN, TAG, 'Received empty plates array or plates is undefined/null.');
            }
            this.recognizedPlates = plates;
            if (this.recognizedPlates && this.recognizedPlates.length === 0 && (this.imagePath || this.selectedPixelMap)) {
                promptAction.showToast({
                    message: '未检测到车牌 (图片)',
                    duration: 2000
                });
            }
            else if (this.recognizedPlates && this.recognizedPlates.length > 0) {
                promptAction.showToast({
                    message: `图片检测到 ${this.recognizedPlates.length} 个车牌`,
                    duration: 2000
                });
            }
        });
        // 系统消息回调
        this.webSocketService.onSystemMessage((message: string) => {
            this.isLoading = false;
            promptAction.showToast({
                message: message,
                duration: 3000
            });
        });
    }
    /**
     * 连接WebSocket服务器
     */
    private connectWebSocket() {
        if (!this.webSocketService.isConnectedToServer()) {
            this.webSocketService.connect();
        }
    }
    /**
     * 选择图片并发送识别请求
     */
    private async selectAndRecognize() {
        if (!this.isConnected) {
            promptAction.showToast({
                message: '未连接到服务器，请稍后再试',
                duration: 2000
            });
            return;
        }
        try {
            const tempImagePath = await this.imageService.selectImageFromGallery();
            if (!tempImagePath) {
                return;
            }
            this.imagePath = tempImagePath;
            this.isLoading = true;
            this.recognizedPlates = [];
            this.selectedPixelMap = null;
            this.selectedImageInfo = null;
            let loadedPixelMap: image.PixelMap | null = null;
            try {
                loadedPixelMap = await this.imageService.loadPixelMap(this.imagePath);
                if (loadedPixelMap) {
                    const imageInfo = loadedPixelMap.getImageInfoSync();
                    if (!imageInfo || !imageInfo.size || imageInfo.size.width === 0 || imageInfo.size.height === 0) {
                        hilog.error(DOMAIN, TAG, `PixelMap loaded, but ImageInfo is invalid: ${JSON.stringify(imageInfo)}`);
                        this.isLoading = false;
                        this.errorMessage = `加载的图片信息无效`;
                        promptAction.showToast({ message: this.errorMessage, duration: 3000 });
                        this.selectedPixelMap = null;
                        this.selectedImageInfo = null;
                        return;
                    }
                    hilog.info(DOMAIN, TAG, `PixelMap loaded and ImageInfo obtained successfully in Index. Width: ${imageInfo.size.width}`);
                    this.selectedPixelMap = loadedPixelMap;
                    this.selectedImageInfo = imageInfo;
                }
                else {
                    hilog.error(DOMAIN, TAG, 'ImageService.loadPixelMap returned null.');
                    throw new Error('加载PixelMap失败 (返回null)');
                }
            }
            catch (pixelMapError) {
                hilog.error(DOMAIN, TAG, `Failed to load PixelMap or get ImageInfo in Index: ${pixelMapError.message || JSON.stringify(pixelMapError)}`);
                this.isLoading = false;
                this.errorMessage = `加载图片预览失败: ${pixelMapError.message || JSON.stringify(pixelMapError)}`;
                promptAction.showToast({ message: this.errorMessage, duration: 3000 });
                this.selectedPixelMap = null;
                this.selectedImageInfo = null;
                return;
            }
            if (!this.selectedPixelMap || !this.selectedImageInfo) {
                hilog.warn(DOMAIN, TAG, "selectedPixelMap or selectedImageInfo is null after load and ImageInfo check, aborting recognition request.");
                if (this.isLoading) {
                    this.isLoading = false;
                }
                return;
            }
            const imageBase64 = await this.imageService.convertImageToBase64(this.imagePath);
            this.webSocketService.sendPlateRecognitionRequest(imageBase64);
        }
        catch (error) {
            this.isLoading = false;
            this.errorMessage = `操作失败: ${error.message || error}`;
            promptAction.showToast({ message: this.errorMessage, duration: 3000 });
        }
    }
    /**
     * 选择视频, 提取帧并发送识别请求
     */
    private async selectAndRecognizeVideo() {
        if (!this.isConnected) {
            promptAction.showToast({ message: '未连接到服务器，请稍后再试', duration: 2000 });
            return;
        }
        try {
            const tempVideoUri = await this.videoService.selectVideoFromGallery();
            if (!tempVideoUri) {
                return; // 用户取消
            }
            // 直接跳转到视频分析页面
            router.push({
                url: 'pages/VideoAnalysisPage',
                params: {
                    videoUri: tempVideoUri
                }
            });
        }
        catch (error) {
            this.errorMessage = `视频操作失败: ${error.message || error}`;
            promptAction.showToast({ message: this.errorMessage, duration: 3000 });
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(239:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(CommonConstants.BACKGROUND_COLOR);
            Column.padding(CommonConstants.PAGE_PADDING);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 标题栏
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(241:7)", "entry");
            // 标题栏
            Row.width('100%');
            // 标题栏
            Row.padding(CommonConstants.PAGE_PADDING);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(CommonConstants.APP_TITLE);
            Text.debugLine("entry/src/main/ets/pages/Index.ets(242:9)", "entry");
            Text.fontSize(CommonConstants.TITLE_FONT_SIZE);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(CommonConstants.TEXT_COLOR);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/Index.ets(247:9)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.isConnected ? '已连接' : '未连接');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(249:9)", "entry");
            Text.fontSize(CommonConstants.SMALL_FONT_SIZE);
            Text.fontColor(this.isConnected ? CommonConstants.SUCCESS_COLOR : CommonConstants.ERROR_COLOR);
        }, Text);
        Text.pop();
        // 标题栏
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // 错误信息
            if (this.errorMessage) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.errorMessage);
                        Text.debugLine("entry/src/main/ets/pages/Index.ets(258:9)", "entry");
                        Text.fontSize(CommonConstants.SMALL_FONT_SIZE);
                        Text.fontColor(CommonConstants.ERROR_COLOR);
                        Text.width('100%');
                        Text.textAlign(TextAlign.Center);
                        Text.padding(CommonConstants.PAGE_PADDING);
                        Text.backgroundColor('#FFEBEE');
                        Text.margin({ bottom: CommonConstants.COMPONENT_SPACING });
                    }, Text);
                    Text.pop();
                });
            }
            // 预览区域: 图片
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // 预览区域: 图片
            if (this.selectedPixelMap && this.selectedImageInfo) { // Image Preview
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Stack.create();
                        Stack.debugLine("entry/src/main/ets/pages/Index.ets(270:9)", "entry");
                        Stack.width('100%');
                        Stack.height(CommonConstants.IMAGE_PREVIEW_HEIGHT);
                        Stack.margin({ bottom: CommonConstants.COMPONENT_SPACING });
                    }, Stack);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create(this.selectedPixelMap);
                        Image.debugLine("entry/src/main/ets/pages/Index.ets(271:9)", "entry");
                        Image.width('100%');
                        Image.height(CommonConstants.IMAGE_PREVIEW_HEIGHT);
                        Image.objectFit(ImageFit.Contain);
                        Image.backgroundColor(CommonConstants.CARD_BACKGROUND_COLOR);
                        Image.alt(CommonConstants.IMAGE_PREVIEW_ALT_COLOR);
                    }, Image);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        __Common__.create();
                        __Common__.width('100%');
                    }, __Common__);
                    {
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            if (isInitialRender) {
                                let componentCall = new PlateAnnotatorCanvas(this, {
                                    pixelMap: this.selectedPixelMap,
                                    plates: this.recognizedPlates,
                                    canvasDisplayHeight: CommonConstants.IMAGE_PREVIEW_HEIGHT,
                                    imageInfo: this.selectedImageInfo
                                }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 278, col: 11 });
                                ViewPU.create(componentCall);
                                let paramsLambda = () => {
                                    return {
                                        pixelMap: this.selectedPixelMap,
                                        plates: this.recognizedPlates,
                                        canvasDisplayHeight: CommonConstants.IMAGE_PREVIEW_HEIGHT,
                                        imageInfo: this.selectedImageInfo
                                    };
                                };
                                componentCall.paramsGenerator_ = paramsLambda;
                            }
                            else {
                                this.updateStateVarsOfChildByElmtId(elmtId, {
                                    pixelMap: this.selectedPixelMap,
                                    plates: this.recognizedPlates,
                                    canvasDisplayHeight: CommonConstants.IMAGE_PREVIEW_HEIGHT,
                                    imageInfo: this.selectedImageInfo
                                });
                            }
                        }, { name: "PlateAnnotatorCanvas" });
                    }
                    __Common__.pop();
                    Stack.pop();
                });
            }
            else if (this.imagePath && !this.isLoading) { // Fallback for image path if pixelmap failed
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create(this.imagePath);
                        Image.debugLine("entry/src/main/ets/pages/Index.ets(291:9)", "entry");
                        Image.width('100%');
                        Image.height(CommonConstants.IMAGE_PREVIEW_HEIGHT);
                        Image.objectFit(ImageFit.Contain);
                        Image.backgroundColor(CommonConstants.CARD_BACKGROUND_COLOR);
                        Image.margin({ bottom: CommonConstants.COMPONENT_SPACING });
                        Image.alt(CommonConstants.IMAGE_PREVIEW_ALT_COLOR);
                    }, Image);
                });
            }
            else { // 默认占位符
                this.ifElseBranchUpdateFunction(2, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/Index.ets(299:9)", "entry");
                        Column.width('100%');
                        Column.height(CommonConstants.IMAGE_PREVIEW_HEIGHT);
                        Column.backgroundColor(CommonConstants.CARD_BACKGROUND_COLOR);
                        Column.justifyContent(FlexAlign.Center);
                        Column.margin({ bottom: CommonConstants.COMPONENT_SPACING });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('未选择图片');
                        Text.debugLine("entry/src/main/ets/pages/Index.ets(300:11)", "entry");
                        Text.fontSize(CommonConstants.BODY_FONT_SIZE);
                        Text.fontColor(CommonConstants.SECONDARY_TEXT_COLOR);
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 操作按钮
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(312:7)", "entry");
            // 操作按钮
            Row.width('100%');
            // 操作按钮
            Row.margin({ bottom: CommonConstants.COMPONENT_SPACING });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('选择图片识别');
            Button.debugLine("entry/src/main/ets/pages/Index.ets(313:9)", "entry");
            Button.height(CommonConstants.BUTTON_HEIGHT);
            Button.backgroundColor(CommonConstants.PRIMARY_COLOR);
            Button.fontColor(Color.White);
            Button.fontSize(CommonConstants.BODY_FONT_SIZE);
            Button.enabled(!this.isLoading);
            Button.layoutWeight(1);
            Button.onClick(() => this.selectAndRecognize());
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('视频分析');
            Button.debugLine("entry/src/main/ets/pages/Index.ets(322:9)", "entry");
            Button.height(CommonConstants.BUTTON_HEIGHT);
            Button.backgroundColor(CommonConstants.SUCCESS_COLOR);
            Button.fontColor(Color.White);
            Button.fontSize(CommonConstants.BODY_FONT_SIZE);
            Button.enabled(!this.isLoading);
            Button.layoutWeight(1);
            Button.margin({ left: CommonConstants.COMPONENT_SPACING / 2 });
            Button.onClick(() => this.selectAndRecognizeVideo());
        }, Button);
        Button.pop();
        // 操作按钮
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // 加载指示器
            if (this.isLoading) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        LoadingProgress.create();
                        LoadingProgress.debugLine("entry/src/main/ets/pages/Index.ets(337:9)", "entry");
                        LoadingProgress.width(30);
                        LoadingProgress.height(30);
                        LoadingProgress.color(CommonConstants.PRIMARY_COLOR);
                        LoadingProgress.margin({ bottom: CommonConstants.COMPONENT_SPACING });
                    }, LoadingProgress);
                });
            }
            // 识别结果
            // Display image results
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // 识别结果
            // Display image results
            if (this.recognizedPlates.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('图片识别结果');
                        Text.debugLine("entry/src/main/ets/pages/Index.ets(347:9)", "entry");
                        Text.fontSize(CommonConstants.SUBTITLE_FONT_SIZE);
                        Text.fontWeight(FontWeight.Bold);
                        Text.fontColor(CommonConstants.TEXT_COLOR);
                        Text.width('100%');
                        Text.margin({ bottom: CommonConstants.COMPONENT_SPACING });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        List.create();
                        List.debugLine("entry/src/main/ets/pages/Index.ets(354:9)", "entry");
                        List.width('100%');
                        List.layoutWeight(1);
                    }, List);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const plate = _item;
                            {
                                const itemCreation = (elmtId, isInitialRender) => {
                                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                    itemCreation2(elmtId, isInitialRender);
                                    if (!isInitialRender) {
                                        ListItem.pop();
                                    }
                                    ViewStackProcessor.StopGetAccessRecording();
                                };
                                const itemCreation2 = (elmtId, isInitialRender) => {
                                    ListItem.create(deepRenderFunction, true);
                                    ListItem.margin({ bottom: 8 });
                                    ListItem.debugLine("entry/src/main/ets/pages/Index.ets(356:13)", "entry");
                                };
                                const deepRenderFunction = (elmtId, isInitialRender) => {
                                    itemCreation(elmtId, isInitialRender);
                                    {
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            if (isInitialRender) {
                                                let componentCall = new PlateResultItem(this, { plateInfo: plate }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 357, col: 15 });
                                                ViewPU.create(componentCall);
                                                let paramsLambda = () => {
                                                    return {
                                                        plateInfo: plate
                                                    };
                                                };
                                                componentCall.paramsGenerator_ = paramsLambda;
                                            }
                                            else {
                                                this.updateStateVarsOfChildByElmtId(elmtId, {});
                                            }
                                        }, { name: "PlateResultItem" });
                                    }
                                    ListItem.pop();
                                };
                                this.observeComponentCreation2(itemCreation2, ListItem);
                                ListItem.pop();
                            }
                        };
                        this.forEachUpdateFunction(elmtId, this.recognizedPlates, forEachItemGenFunction);
                    }, ForEach);
                    ForEach.pop();
                    List.pop();
                });
            }
            else if (!this.isLoading && (this.imagePath || this.selectedPixelMap)) { // 移除对currentFramePixelMap的引用
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('未检测到车牌 (图片)');
                        Text.debugLine("entry/src/main/ets/pages/Index.ets(365:9)", "entry");
                        Text.fontSize(CommonConstants.BODY_FONT_SIZE);
                        Text.fontColor(CommonConstants.SECONDARY_TEXT_COLOR);
                        Text.margin({ top: CommonConstants.COMPONENT_SPACING });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(2, () => {
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Index";
    }
}
registerNamedRoute(() => new Index(undefined, {}), "", { bundleName: "com.example.yolo1", moduleName: "entry", pagePath: "pages/Index", pageFullPath: "entry/src/main/ets/pages/Index", integratedHsp: "false", moduleType: "followWithHap" });
