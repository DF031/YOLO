if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface PlateAnnotatorCanvas_Params {
    pixelMap?: image.PixelMap | null;
    plates?: PlateInfo[];
    canvasDisplayHeight?: number;
    imageInfo?: image.ImageInfo | null;
    settings?;
    context?;
    actualCanvasWidth?: number;
    actualCanvasHeight?: number;
}
import type image from "@ohos:multimedia.image";
import hilog from "@ohos:hilog";
import type { BusinessError } from "@ohos:base";
import type { PlateInfo } from '../model/MessageTypes';
import { CommonConstants } from "@normalized:N&&&entry/src/main/ets/common/constants/CommonConstants&";
const DOMAIN = 0x0000;
const TAG = 'PlateAnnotatorCanvas';
interface ExpectedTextMetrics {
    width: number;
}
export class PlateAnnotatorCanvas extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__pixelMap = new SynchedPropertyObjectOneWayPU(params.pixelMap, this, "pixelMap");
        this.__plates = new SynchedPropertyObjectOneWayPU(params.plates, this, "plates");
        this.__canvasDisplayHeight = new SynchedPropertySimpleOneWayPU(params.canvasDisplayHeight, this, "canvasDisplayHeight");
        this.__imageInfo = new SynchedPropertyObjectOneWayPU(params.imageInfo, this, "imageInfo");
        this.settings = new RenderingContextSettings(true);
        this.context = new CanvasRenderingContext2D(this.settings);
        this.__actualCanvasWidth = new ObservedPropertySimplePU(0, this, "actualCanvasWidth");
        this.__actualCanvasHeight = new ObservedPropertySimplePU(0, this, "actualCanvasHeight");
        this.setInitiallyProvidedValue(params);
        this.declareWatch("pixelMap", this.onPixelMapPropChange);
        this.declareWatch("plates", this.onPlatesPropChange);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: PlateAnnotatorCanvas_Params) {
        if (params.settings !== undefined) {
            this.settings = params.settings;
        }
        if (params.context !== undefined) {
            this.context = params.context;
        }
        if (params.actualCanvasWidth !== undefined) {
            this.actualCanvasWidth = params.actualCanvasWidth;
        }
        if (params.actualCanvasHeight !== undefined) {
            this.actualCanvasHeight = params.actualCanvasHeight;
        }
    }
    updateStateVars(params: PlateAnnotatorCanvas_Params) {
        this.__pixelMap.reset(params.pixelMap);
        this.__plates.reset(params.plates);
        this.__canvasDisplayHeight.reset(params.canvasDisplayHeight);
        this.__imageInfo.reset(params.imageInfo);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__pixelMap.purgeDependencyOnElmtId(rmElmtId);
        this.__plates.purgeDependencyOnElmtId(rmElmtId);
        this.__canvasDisplayHeight.purgeDependencyOnElmtId(rmElmtId);
        this.__imageInfo.purgeDependencyOnElmtId(rmElmtId);
        this.__actualCanvasWidth.purgeDependencyOnElmtId(rmElmtId);
        this.__actualCanvasHeight.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__pixelMap.aboutToBeDeleted();
        this.__plates.aboutToBeDeleted();
        this.__canvasDisplayHeight.aboutToBeDeleted();
        this.__imageInfo.aboutToBeDeleted();
        this.__actualCanvasWidth.aboutToBeDeleted();
        this.__actualCanvasHeight.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __pixelMap: SynchedPropertySimpleOneWayPU<image.PixelMap | null>;
    get pixelMap() {
        return this.__pixelMap.get();
    }
    set pixelMap(newValue: image.PixelMap | null) {
        this.__pixelMap.set(newValue);
    }
    private __plates: SynchedPropertySimpleOneWayPU<PlateInfo[]>;
    get plates() {
        return this.__plates.get();
    }
    set plates(newValue: PlateInfo[]) {
        this.__plates.set(newValue);
    }
    private __canvasDisplayHeight: SynchedPropertySimpleOneWayPU<number>;
    get canvasDisplayHeight() {
        return this.__canvasDisplayHeight.get();
    }
    set canvasDisplayHeight(newValue: number) {
        this.__canvasDisplayHeight.set(newValue);
    }
    private __imageInfo: SynchedPropertySimpleOneWayPU<image.ImageInfo | null>;
    get imageInfo() {
        return this.__imageInfo.get();
    }
    set imageInfo(newValue: image.ImageInfo | null) {
        this.__imageInfo.set(newValue);
    }
    private settings;
    private context;
    private __actualCanvasWidth: ObservedPropertySimplePU<number>;
    get actualCanvasWidth() {
        return this.__actualCanvasWidth.get();
    }
    set actualCanvasWidth(newValue: number) {
        this.__actualCanvasWidth.set(newValue);
    }
    private __actualCanvasHeight: ObservedPropertySimplePU<number>;
    get actualCanvasHeight() {
        return this.__actualCanvasHeight.get();
    }
    set actualCanvasHeight(newValue: number) {
        this.__actualCanvasHeight.set(newValue);
    }
    onPixelMapPropChange(): void {
        hilog.info(DOMAIN, TAG, 'pixelMap prop changed, redrawing canvas.');
        this.drawCanvas();
    }
    onPlatesPropChange(): void {
        hilog.info(DOMAIN, TAG, 'plates prop changed, redrawing canvas.');
        this.drawCanvas();
    }
    private drawCanvas() {
        if (!this.context) {
            hilog.warn(DOMAIN, TAG, 'Canvas context not ready for drawing.');
            return;
        }
        const canvasWidthVp = this.actualCanvasWidth;
        const canvasHeightVp = this.actualCanvasHeight;
        this.context.clearRect(0, 0, canvasWidthVp, canvasHeightVp);
        try {
            if (!this.imageInfo || !this.imageInfo.size) { // 仍然需要 imageInfo 来计算正确的缩放比例
                hilog.error(DOMAIN, TAG, `Received invalid imageInfo prop for annotations: ${JSON.stringify(this.imageInfo)}`);
                // 可能不需要在这里绘制错误文本，因为底下的Image组件会处理图片加载失败的情况
                return;
            }
            const imagePxWidth = this.imageInfo.size.width;
            const imagePxHeight = this.imageInfo.size.height;
            if (imagePxWidth <= 0 || imagePxHeight <= 0) {
                hilog.error(DOMAIN, TAG, `PixelMap dimensions from prop are zero or invalid for annotations: ${imagePxWidth}x${imagePxHeight}`);
                return;
            }
            const imageAspectRatio = imagePxWidth / imagePxHeight;
            // canvasWidthVp 和 canvasHeightVp 是此Canvas组件的实际VP尺寸，应与底下Image组件的图片显示区域一致
            const canvasAspectRatio = canvasWidthVp / canvasHeightVp;
            let drawnImageWidthVp: number; // 这是图片在Image组件中实际显示的VP宽度
            let drawnImageHeightVp: number; // 这是图片在Image组件中实际显示的VP高度
            if (imageAspectRatio > canvasAspectRatio) {
                drawnImageWidthVp = canvasWidthVp;
                drawnImageHeightVp = canvasWidthVp / imageAspectRatio;
            }
            else {
                drawnImageHeightVp = canvasHeightVp;
                drawnImageWidthVp = canvasHeightVp * imageAspectRatio;
            }
            const offsetX_vp = (canvasWidthVp - drawnImageWidthVp) / 2; // 图片在Image组件中的X偏移 (居中)
            const offsetY_vp = (canvasHeightVp - drawnImageHeightVp) / 2; // 图片在Image组件中的Y偏移 (居中)
            if (this.plates && this.plates.length > 0) {
                this.plates.forEach((plate, index) => {
                    const x_min_px = plate.box[0];
                    const y_min_px = plate.box[1];
                    const x_max_px = plate.box[2];
                    const y_max_px = plate.box[3];
                    const scaleX_px_to_vp = drawnImageWidthVp / imagePxWidth;
                    const scaleY_px_to_vp = drawnImageHeightVp / imagePxHeight;
                    const rectX_vp = (x_min_px * scaleX_px_to_vp) + offsetX_vp;
                    const rectY_vp = (y_min_px * scaleY_px_to_vp) + offsetY_vp;
                    const rectWidth_vp = (x_max_px - x_min_px) * scaleX_px_to_vp;
                    const rectHeight_vp = (y_max_px - y_min_px) * scaleY_px_to_vp;
                    this.context.strokeStyle = CommonConstants.ANNOTATION_BOX_COLOR || '#FF0000';
                    this.context.lineWidth = CommonConstants.ANNOTATION_LINE_WIDTH || 2;
                    this.context.strokeRect(rectX_vp, rectY_vp, rectWidth_vp, rectHeight_vp);
                    const fontSizeVp = CommonConstants.ANNOTATION_FONT_SIZE_VP || 12;
                    const text = `${plate.text} (${(plate.confidence * 100).toFixed(1)}%)`;
                    this.context.font = `${fontSizeVp}vp sans-serif`;
                    const textMetrics = this.context.measureText(text) as ExpectedTextMetrics;
                    const textWidthVp = textMetrics.width;
                    const textHeightVp = fontSizeVp;
                    const textBgPaddingVp = 2;
                    const textY_vp = rectY_vp - textBgPaddingVp;
                    const textX_vp = rectX_vp + textBgPaddingVp;
                    this.context.fillStyle = CommonConstants.ANNOTATION_TEXT_BACKGROUND_COLOR || 'rgba(255, 255, 255, 0.75)';
                    this.context.fillRect(rectX_vp, textY_vp - textHeightVp - textBgPaddingVp, textWidthVp + (textBgPaddingVp * 2), textHeightVp + (textBgPaddingVp * 2));
                    this.context.fillStyle = CommonConstants.ANNOTATION_TEXT_COLOR || '#FF0000';
                    this.context.textAlign = 'left';
                    this.context.textBaseline = 'bottom';
                    this.context.fillText(text, textX_vp, textY_vp);
                    hilog.debug(DOMAIN, TAG, `Drew plate ${index}: ${text} at [${rectX_vp.toFixed(2)}, ${rectY_vp.toFixed(2)}, ${rectWidth_vp.toFixed(2)}, ${rectHeight_vp.toFixed(2)}]vp`);
                });
            }
        }
        catch (e) {
            const error = e as BusinessError;
            hilog.error(DOMAIN, TAG, `Error drawing canvas: ${error.message || JSON.stringify(error)} Code: ${error.code}`);
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Canvas.create(this.context);
            Canvas.debugLine("entry/src/main/ets/components/PlateAnnotatorCanvas.ets(139:5)", "entry");
            Canvas.width('100%');
            Canvas.height(this.canvasDisplayHeight);
            Canvas.backgroundColor(Color.Transparent);
            Canvas.onReady(() => {
                if (this.context) {
                    this.actualCanvasWidth = this.context.width;
                    this.actualCanvasHeight = this.context.height;
                    hilog.info(DOMAIN, TAG, `Canvas onReady. Context dimensions: ${this.actualCanvasWidth}x${this.actualCanvasHeight}vp. CanvasDisplayHeight prop: ${this.canvasDisplayHeight}vp`);
                    this.drawCanvas();
                }
            });
            Canvas.onAreaChange((_oldValue, newValue) => {
                this.actualCanvasWidth = newValue.width as number;
                this.actualCanvasHeight = newValue.height as number;
                hilog.info(DOMAIN, TAG, `Canvas onAreaChange. New size: ${this.actualCanvasWidth}x${this.actualCanvasHeight}vp`);
                this.drawCanvas();
            });
        }, Canvas);
        Canvas.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
