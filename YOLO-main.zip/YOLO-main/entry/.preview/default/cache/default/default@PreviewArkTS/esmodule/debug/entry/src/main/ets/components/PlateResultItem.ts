if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface PlateResultItem_Params {
    plateInfo?: PlateInfo;
}
import type { PlateInfo } from '../model/MessageTypes';
import { CommonConstants } from "@normalized:N&&&entry/src/main/ets/common/constants/CommonConstants&";
export class PlateResultItem extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.plateInfo = { text: '', confidence: 0, box: [0, 0, 0, 0] };
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: PlateResultItem_Params) {
        if (params.plateInfo !== undefined) {
            this.plateInfo = params.plateInfo;
        }
    }
    updateStateVars(params: PlateResultItem_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private plateInfo: PlateInfo;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/components/PlateResultItem.ets(13:5)", "entry");
            Row.width('100%');
            Row.height(CommonConstants.RESULT_ITEM_HEIGHT);
            Row.backgroundColor(CommonConstants.CARD_BACKGROUND_COLOR);
            Row.borderRadius(8);
            Row.padding(CommonConstants.PAGE_PADDING);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/components/PlateResultItem.ets(14:7)", "entry");
            Column.alignItems(HorizontalAlign.Start);
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.plateInfo.text);
            Text.debugLine("entry/src/main/ets/components/PlateResultItem.ets(15:9)", "entry");
            Text.fontSize(CommonConstants.SUBTITLE_FONT_SIZE);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(CommonConstants.TEXT_COLOR);
            Text.margin({ bottom: 4 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/components/PlateResultItem.ets(21:9)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('置信度:');
            Text.debugLine("entry/src/main/ets/components/PlateResultItem.ets(22:11)", "entry");
            Text.fontSize(CommonConstants.SMALL_FONT_SIZE);
            Text.fontColor(CommonConstants.SECONDARY_TEXT_COLOR);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`${(this.plateInfo.confidence * 100).toFixed(1)}%`);
            Text.debugLine("entry/src/main/ets/components/PlateResultItem.ets(26:11)", "entry");
            Text.fontSize(CommonConstants.SMALL_FONT_SIZE);
            Text.fontColor(this.getConfidenceColor());
            Text.fontWeight(FontWeight.Bold);
            Text.margin({ left: 4 });
        }, Text);
        Text.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/components/PlateResultItem.ets(36:7)", "entry");
            Column.alignItems(HorizontalAlign.End);
            Column.width('40%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('位置:');
            Text.debugLine("entry/src/main/ets/components/PlateResultItem.ets(37:9)", "entry");
            Text.fontSize(CommonConstants.SMALL_FONT_SIZE);
            Text.fontColor(CommonConstants.SECONDARY_TEXT_COLOR);
            Text.margin({ bottom: 4 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`[${this.plateInfo.box.join(', ')}]`);
            Text.debugLine("entry/src/main/ets/components/PlateResultItem.ets(42:9)", "entry");
            Text.fontSize(CommonConstants.SMALL_FONT_SIZE);
            Text.fontColor(CommonConstants.SECONDARY_TEXT_COLOR);
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        Column.pop();
        Row.pop();
    }
    /**
     * 根据置信度获取对应的颜色
     * @returns 颜色值
     */
    private getConfidenceColor(): string {
        if (this.plateInfo.confidence >= 0.9) {
            return CommonConstants.SUCCESS_COLOR;
        }
        else if (this.plateInfo.confidence >= 0.7) {
            return CommonConstants.PRIMARY_COLOR;
        }
        else {
            return CommonConstants.WARNING_COLOR;
        }
    }
    rerender() {
        this.updateDirtyElements();
    }
}
