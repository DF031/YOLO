import hilog from "@ohos:hilog";
import image from "@ohos:multimedia.image";
import type { WebSocketService } from './WebSocketService';
import type { VideoService } from './VideoService';
import type { PlateInfo } from '../model/MessageTypes';
const DOMAIN = 0x0003; // 为RealTimeAnalysisService分配唯一域
const TAG = 'RealTimeAnalysisService';
// 实时分析配置接口
export interface RealTimeAnalysisConfig {
    frameInterval: number; // 帧间隔（毫秒）
    adaptiveFrameRate: boolean; // 是否启用自适应帧率
    motionDetection: boolean; // 是否启用运动检测
    minConfidence: number; // 最小置信度阈值
    cacheResults: boolean; // 是否缓存结果
}
// 配置选项接口
export interface RealTimeAnalysisConfigOptions {
    frameInterval?: number;
    adaptiveFrameRate?: boolean;
    motionDetection?: boolean;
    minConfidence?: number;
    cacheResults?: boolean;
}
// 默认配置
const DEFAULT_CONFIG: RealTimeAnalysisConfig = {
    frameInterval: 500,
    adaptiveFrameRate: true,
    motionDetection: true,
    minConfidence: 0.6,
    cacheResults: true // 默认缓存结果
};
// 实时分析状态枚举
export enum AnalysisState {
    IDLE = "idle",
    INITIALIZING = "initializing",
    RUNNING = "running",
    PAUSED = "paused",
    ERROR = "error" // 错误
}
// 实时分析结果接口
export interface RealTimeAnalysisResult {
    frameId: number; // 帧ID
    timestamp: number; // 时间戳
    plates: PlateInfo[]; // 识别到的车牌
    processingTimeMs: number; // 处理时间（毫秒）
    imageWidth: number; // 图像宽度
    imageHeight: number; // 图像高度
}
export class RealTimeAnalysisService {
    private webSocketService: WebSocketService;
    private videoService: VideoService;
    private config: RealTimeAnalysisConfig;
    private state: AnalysisState = AnalysisState.IDLE;
    private errorMessage: string = '';
    private frameProcessingTimer: number | null = null;
    private lastFrameTime: number = 0;
    private frameCounter: number = 0;
    private resultCache: Map<string, RealTimeAnalysisResult> = new Map();
    private currentSurfaceId: string = '';
    private isProcessingFrame: boolean = false;
    private networkQuality: number = 100; // 网络质量指标（0-100）
    private lastMotionScore: number = 0; // 上一帧的运动分数
    private pixelMapCache: image.PixelMap | null = null;
    // 回调函数
    private onStateChangeCallback: ((state: AnalysisState, message?: string) => void) | null = null;
    private onResultCallback: ((result: RealTimeAnalysisResult) => void) | null = null;
    private onPreviewFrameCallback: ((pixelMap: image.PixelMap) => void) | null = null;
    private onErrorCallback: ((error: string) => void) | null = null;
    /**
     * 构造函数
     * @param webSocketService WebSocket服务实例
     * @param videoService 视频服务实例
     * @param config 配置参数（可选）
     */
    constructor(webSocketService: WebSocketService, videoService: VideoService, config?: RealTimeAnalysisConfigOptions) {
        this.webSocketService = webSocketService;
        this.videoService = videoService;
        // 复制默认配置
        this.config = {
            frameInterval: DEFAULT_CONFIG.frameInterval,
            adaptiveFrameRate: DEFAULT_CONFIG.adaptiveFrameRate,
            motionDetection: DEFAULT_CONFIG.motionDetection,
            minConfidence: DEFAULT_CONFIG.minConfidence,
            cacheResults: DEFAULT_CONFIG.cacheResults
        };
        // 应用用户配置
        if (config) {
            if (config.frameInterval !== undefined)
                this.config.frameInterval = config.frameInterval;
            if (config.adaptiveFrameRate !== undefined)
                this.config.adaptiveFrameRate = config.adaptiveFrameRate;
            if (config.motionDetection !== undefined)
                this.config.motionDetection = config.motionDetection;
            if (config.minConfidence !== undefined)
                this.config.minConfidence = config.minConfidence;
            if (config.cacheResults !== undefined)
                this.config.cacheResults = config.cacheResults;
        }
        hilog.info(DOMAIN, TAG, 'RealTimeAnalysisService created');
    }
    /**
     * 初始化服务
     * @returns 是否初始化成功
     */
    async initialize(): Promise<boolean> {
        try {
            this.setState(AnalysisState.INITIALIZING);
            // 初始化摄像头
            const cameraSuccess = await this.initializeCamera();
            if (!cameraSuccess) {
                this.setError('初始化摄像头失败');
                return false;
            }
            // 确保WebSocket已连接
            if (!this.webSocketService.isConnectedToServer()) {
                this.webSocketService.connect();
            }
            // 设置WebSocket回调
            this.setupWebSocketCallbacks();
            this.setState(AnalysisState.IDLE);
            return true;
        }
        catch (error) {
            const errorMsg = `初始化失败: ${error instanceof Error ? error.message : String(error)}`;
            this.setError(errorMsg);
            return false;
        }
    }
    /**
     * 开始实时分析
     * @param surfaceId 用于预览的Surface ID
     * @returns 是否成功启动
     */
    async startAnalysis(surfaceId: string): Promise<boolean> {
        if (this.state === AnalysisState.RUNNING) {
            hilog.info(DOMAIN, TAG, 'Analysis already running');
            return true;
        }
        if (this.state === AnalysisState.ERROR) {
            hilog.error(DOMAIN, TAG, `Cannot start analysis in ERROR state: ${this.errorMessage}`);
            return false;
        }
        try {
            this.currentSurfaceId = surfaceId;
            // 启动摄像头预览
            const previewSuccess = await this.startCameraPreview(surfaceId);
            if (!previewSuccess) {
                this.setError('启动摄像头预览失败');
                return false;
            }
            // 启动帧处理定时器
            this.startFrameProcessing();
            this.setState(AnalysisState.RUNNING);
            hilog.info(DOMAIN, TAG, 'Real-time analysis started');
            return true;
        }
        catch (error) {
            const errorMsg = `启动分析失败: ${error instanceof Error ? error.message : String(error)}`;
            this.setError(errorMsg);
            return false;
        }
    }
    /**
     * 暂停实时分析
     */
    pauseAnalysis(): void {
        if (this.state !== AnalysisState.RUNNING) {
            return;
        }
        this.stopFrameProcessing();
        this.setState(AnalysisState.PAUSED);
        hilog.info(DOMAIN, TAG, 'Real-time analysis paused');
    }
    /**
     * 恢复实时分析
     */
    resumeAnalysis(): void {
        if (this.state !== AnalysisState.PAUSED) {
            return;
        }
        this.startFrameProcessing();
        this.setState(AnalysisState.RUNNING);
        hilog.info(DOMAIN, TAG, 'Real-time analysis resumed');
    }
    /**
     * 停止实时分析
     */
    async stopAnalysis(): Promise<void> {
        this.stopFrameProcessing();
        await this.stopCameraPreview();
        this.setState(AnalysisState.IDLE);
        hilog.info(DOMAIN, TAG, 'Real-time analysis stopped');
    }
    /**
     * 释放资源
     */
    async release(): Promise<void> {
        this.stopFrameProcessing();
        await this.releaseCamera();
        this.clearCache();
        this.setState(AnalysisState.IDLE);
        hilog.info(DOMAIN, TAG, 'RealTimeAnalysisService resources released');
    }
    /**
     * 更新配置
     * @param config 新的配置参数
     */
    updateConfig(config: RealTimeAnalysisConfigOptions): void {
        // 保存旧配置的帧间隔
        const oldFrameInterval = this.config.frameInterval;
        // 应用新配置
        if (config.frameInterval !== undefined)
            this.config.frameInterval = config.frameInterval;
        if (config.adaptiveFrameRate !== undefined)
            this.config.adaptiveFrameRate = config.adaptiveFrameRate;
        if (config.motionDetection !== undefined)
            this.config.motionDetection = config.motionDetection;
        if (config.minConfidence !== undefined)
            this.config.minConfidence = config.minConfidence;
        if (config.cacheResults !== undefined)
            this.config.cacheResults = config.cacheResults;
        // 如果帧间隔发生变化且正在运行，重新启动帧处理
        if (oldFrameInterval !== this.config.frameInterval && this.state === AnalysisState.RUNNING) {
            this.stopFrameProcessing();
            this.startFrameProcessing();
        }
        hilog.info(DOMAIN, TAG, `Config updated: ${JSON.stringify(this.config)}`);
    }
    /**
     * 获取当前状态
     * @returns 当前状态
     */
    getState(): AnalysisState {
        return this.state;
    }
    /**
     * 获取错误信息
     * @returns 错误信息
     */
    getErrorMessage(): string {
        return this.errorMessage;
    }
    /**
     * 设置状态变化回调
     * @param callback 回调函数
     */
    onStateChange(callback: (state: AnalysisState, message?: string) => void): void {
        this.onStateChangeCallback = callback;
    }
    /**
     * 设置结果回调
     * @param callback 回调函数
     */
    onResult(callback: (result: RealTimeAnalysisResult) => void): void {
        this.onResultCallback = callback;
    }
    /**
     * 设置预览帧回调
     * @param callback 回调函数
     */
    onPreviewFrame(callback: (pixelMap: image.PixelMap) => void): void {
        this.onPreviewFrameCallback = callback;
    }
    /**
     * 设置错误回调
     * @param callback 回调函数
     */
    onError(callback: (error: string) => void): void {
        this.onErrorCallback = callback;
    }
    // 以下是私有方法
    /**
     * 设置状态
     * @param state 新状态
     * @param message 可选消息
     */
    private setState(state: AnalysisState, message?: string): void {
        this.state = state;
        if (this.onStateChangeCallback) {
            this.onStateChangeCallback(state, message);
        }
        hilog.info(DOMAIN, TAG, `State changed to: ${state}${message ? `, message: ${message}` : ''}`);
    }
    /**
     * 设置错误状态
     * @param errorMessage 错误信息
     */
    private setError(errorMessage: string): void {
        this.errorMessage = errorMessage;
        this.state = AnalysisState.ERROR;
        if (this.onErrorCallback) {
            this.onErrorCallback(errorMessage);
        }
        if (this.onStateChangeCallback) {
            this.onStateChangeCallback(AnalysisState.ERROR, errorMessage);
        }
        hilog.error(DOMAIN, TAG, `Error: ${errorMessage}`);
    }
    /**
     * 初始化摄像头
     * @returns 是否初始化成功
     */
    private async initializeCamera(): Promise<boolean> {
        try {
            // 模拟摄像头初始化
            hilog.info(DOMAIN, TAG, '模拟摄像头初始化');
            // 在实际实现中，这里应该使用鸿蒙的摄像头API
            // 由于API兼容性问题，这里使用模拟实现
            // 延迟一段时间模拟初始化过程
            await new Promise<void>((resolve) => {
                setTimeout(() => {
                    resolve();
                }, 500);
            });
            hilog.info(DOMAIN, TAG, 'Camera initialized successfully (simulated)');
            return true;
        }
        catch (error) {
            const errorMsg = error instanceof Error ? error.message : String(error);
            hilog.error(DOMAIN, TAG, `Camera initialization error: ${errorMsg}`);
            return false;
        }
    }
    /**
     * 启动摄像头预览
     * @param surfaceId 用于预览的Surface ID
     * @returns 是否成功启动预览
     */
    private async startCameraPreview(surfaceId: string): Promise<boolean> {
        try {
            this.currentSurfaceId = surfaceId;
            // 模拟摄像头预览启动
            hilog.info(DOMAIN, TAG, `模拟摄像头预览启动，Surface ID: ${surfaceId}`);
            // 在实际实现中，这里应该使用鸿蒙的摄像头API
            // 由于API兼容性问题，这里使用模拟实现
            // 延迟一段时间模拟启动过程
            await new Promise<void>((resolve) => {
                setTimeout(() => {
                    resolve();
                }, 300);
            });
            hilog.info(DOMAIN, TAG, 'Camera preview started (simulated)');
            return true;
        }
        catch (error) {
            const errorMsg = error instanceof Error ? error.message : String(error);
            hilog.error(DOMAIN, TAG, `Start camera preview error: ${errorMsg}`);
            return false;
        }
    }
    /**
     * 停止摄像头预览
     */
    private async stopCameraPreview(): Promise<void> {
        try {
            // 模拟摄像头预览停止
            hilog.info(DOMAIN, TAG, '模拟摄像头预览停止');
            // 在实际实现中，这里应该使用鸿蒙的摄像头API
            // 由于API兼容性问题，这里使用模拟实现
            // 延迟一段时间模拟停止过程
            await new Promise<void>((resolve) => {
                setTimeout(() => {
                    resolve();
                }, 200);
            });
            hilog.info(DOMAIN, TAG, 'Camera preview stopped (simulated)');
        }
        catch (error) {
            const errorMsg = error instanceof Error ? error.message : String(error);
            hilog.error(DOMAIN, TAG, `Stop camera preview error: ${errorMsg}`);
        }
    }
    /**
     * 释放摄像头资源
     */
    private async releaseCamera(): Promise<void> {
        try {
            await this.stopCameraPreview();
            // 模拟摄像头资源释放
            hilog.info(DOMAIN, TAG, '模拟摄像头资源释放');
            // 在实际实现中，这里应该使用鸿蒙的摄像头API
            // 由于API兼容性问题，这里使用模拟实现
            hilog.info(DOMAIN, TAG, 'Camera resources released (simulated)');
        }
        catch (error) {
            const errorMsg = error instanceof Error ? error.message : String(error);
            hilog.error(DOMAIN, TAG, `Release camera error: ${errorMsg}`);
        }
    }
    /**
     * 设置WebSocket回调
     */
    private setupWebSocketCallbacks(): void {
        // 帧识别结果回调
        this.webSocketService.onFrameResult((frameId: number, plates: PlateInfo[]) => {
            hilog.info(DOMAIN, TAG, `Received frame_result for frameId ${frameId} with ${plates.length} plates`);
            if (this.state !== AnalysisState.RUNNING && this.state !== AnalysisState.PAUSED) {
                return;
            }
            const endTime = Date.now();
            const startTime = this.lastFrameTime;
            const processingTimeMs = endTime - startTime;
            // 创建结果对象
            const result: RealTimeAnalysisResult = {
                frameId: frameId,
                timestamp: endTime,
                plates: plates,
                processingTimeMs: processingTimeMs,
                imageWidth: this.pixelMapCache?.getImageInfoSync()?.size?.width || 0,
                imageHeight: this.pixelMapCache?.getImageInfoSync()?.size?.height || 0
            };
            // 缓存结果
            if (this.config.cacheResults) {
                this.resultCache.set(frameId.toString(), result);
                // 限制缓存大小
                if (this.resultCache.size > 100) {
                    // 获取第一个键
                    const keys = Array.from(this.resultCache.keys());
                    if (keys.length > 0) {
                        this.resultCache.delete(keys[0]);
                    }
                }
            }
            // 调用结果回调
            if (this.onResultCallback) {
                this.onResultCallback(result);
            }
            this.isProcessingFrame = false;
        });
        // 系统消息回调
        this.webSocketService.onSystemMessage((message: string) => {
            hilog.info(DOMAIN, TAG, `Received system message: ${message}`);
        });
        // 错误回调
        this.webSocketService.onError((error: string) => {
            hilog.error(DOMAIN, TAG, `WebSocket error: ${error}`);
            if (this.state === AnalysisState.RUNNING) {
                this.pauseAnalysis();
            }
        });
    }
    /**
     * 启动帧处理定时器
     */
    private startFrameProcessing(): void {
        this.stopFrameProcessing();
        this.frameProcessingTimer = setInterval(() => {
            this.processNextFrame();
        }, this.config.frameInterval);
        hilog.info(DOMAIN, TAG, `Frame processing started with interval ${this.config.frameInterval}ms`);
    }
    /**
     * 停止帧处理定时器
     */
    private stopFrameProcessing(): void {
        if (this.frameProcessingTimer !== null) {
            clearInterval(this.frameProcessingTimer);
            this.frameProcessingTimer = null;
            hilog.info(DOMAIN, TAG, 'Frame processing stopped');
        }
    }
    /**
     * 处理下一帧
     */
    private async processNextFrame(): Promise<void> {
        if (this.isProcessingFrame || this.state !== AnalysisState.RUNNING) {
            return;
        }
        try {
            this.isProcessingFrame = true;
            this.lastFrameTime = Date.now();
            this.frameCounter++;
            // 捕获当前帧
            const pixelMap = await this.captureCurrentFrame();
            if (!pixelMap) {
                this.isProcessingFrame = false;
                return;
            }
            // 保存当前帧的PixelMap
            this.pixelMapCache = pixelMap;
            // 如果启用了运动检测，检查是否有足够的运动
            if (this.config.motionDetection && !this.hasSignificantMotion(pixelMap)) {
                hilog.info(DOMAIN, TAG, 'No significant motion detected, skipping frame');
                this.isProcessingFrame = false;
                return;
            }
            // 调用预览帧回调
            if (this.onPreviewFrameCallback) {
                this.onPreviewFrameCallback(pixelMap);
            }
            // 将帧转换为Base64
            const frameBase64 = await this.videoService.convertPixelMapToBase64(pixelMap);
            if (!frameBase64) {
                hilog.error(DOMAIN, TAG, 'Failed to convert frame to Base64');
                this.isProcessingFrame = false;
                return;
            }
            // 发送帧到服务器进行分析
            const frameId = Date.now();
            this.webSocketService.sendVideoFrameRequest(frameBase64, frameId);
            hilog.info(DOMAIN, TAG, `Frame ${this.frameCounter} sent for analysis with ID ${frameId}`);
            // 如果启用了自适应帧率，根据网络质量调整帧间隔
            if (this.config.adaptiveFrameRate) {
                this.adjustFrameInterval();
            }
        }
        catch (error) {
            hilog.error(DOMAIN, TAG, `Process frame error: ${error instanceof Error ? error.message : String(error)}`);
            this.isProcessingFrame = false;
        }
    }
    /**
     * 捕获当前帧
     * @returns 当前帧的PixelMap
     */
    private async captureCurrentFrame(): Promise<image.PixelMap | null> {
        // 这里应该实现从摄像头捕获当前帧的逻辑
        // 由于鸿蒙API限制，这里使用模拟实现
        // 实际实现应该使用摄像头API获取当前帧
        // 例如：return await this.cameraOutput.captureFrame();
        // 模拟实现：创建一个简单的PixelMap
        try {
            // 创建一个简单的图像源
            const imageSource = image.createImageSource('/data/storage/el2/base/haps/entry/files/test_image.jpg');
            // 创建PixelMap选项
            const options: image.InitializationOptions = {
                alphaType: 0,
                editable: true,
                pixelFormat: 4,
                size: { height: 480, width: 640 }
            };
            // 创建PixelMap
            const pixelMap = await imageSource.createPixelMap(options);
            return pixelMap;
        }
        catch (error) {
            const errorMsg = error instanceof Error ? error.message : String(error);
            hilog.error(DOMAIN, TAG, `Capture frame error: ${errorMsg}`);
            return null;
        }
    }
    /**
     * 检查是否有显著运动
     * @param pixelMap 当前帧
     * @returns 是否有显著运动
     */
    private hasSignificantMotion(pixelMap: image.PixelMap): boolean {
        // 这里应该实现运动检测算法
        // 由于复杂度限制，这里使用模拟实现
        // 实际实现应该比较当前帧与上一帧的差异
        // 例如：计算两帧之间的均方差或结构相似度
        // 模拟实现：随机返回true或false，但大部分情况下返回true
        const motionScore = Math.random();
        const hasMotion = motionScore > 0.2; // 80%的概率返回true
        this.lastMotionScore = motionScore;
        return hasMotion;
    }
    /**
     * 根据网络质量调整帧间隔
     */
    private adjustFrameInterval(): void {
        // 这里应该根据网络质量调整帧间隔
        // 由于复杂度限制，这里使用模拟实现
        // 实际实现应该根据WebSocket响应时间或其他网络指标调整
        // 例如：如果响应时间增加，增加帧间隔；如果响应时间减少，减少帧间隔
        // 模拟实现：根据处理时间调整帧间隔
        const processingTime = Date.now() - this.lastFrameTime;
        if (processingTime > this.config.frameInterval * 1.5) {
            // 处理时间过长，增加帧间隔
            const newInterval = Math.min(2000, this.config.frameInterval * 1.2);
            if (newInterval !== this.config.frameInterval) {
                const config: RealTimeAnalysisConfigOptions = {};
                config.frameInterval = Math.round(newInterval);
                this.updateConfig(config);
            }
        }
        else if (processingTime < this.config.frameInterval * 0.5 && this.config.frameInterval > 200) {
            // 处理时间很短，减少帧间隔
            const newInterval = Math.max(200, this.config.frameInterval * 0.8);
            if (newInterval !== this.config.frameInterval) {
                const config: RealTimeAnalysisConfigOptions = {};
                config.frameInterval = Math.round(newInterval);
                this.updateConfig(config);
            }
        }
    }
    /**
     * 清除缓存
     */
    private clearCache(): void {
        this.resultCache.clear();
        if (this.pixelMapCache) {
            this.pixelMapCache.release();
            this.pixelMapCache = null;
        }
        hilog.info(DOMAIN, TAG, 'Cache cleared');
    }
}
