if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface RealTimeAnalysisTestPage_Params {
    serviceState?: string;
    errorMessage?: string;
    isConnected?: boolean;
    isInitialized?: boolean;
    isRunning?: boolean;
    frameCount?: number;
    processingTime?: number;
    recognizedPlates?: PlateInfo[];
    currentPixelMap?: image.PixelMap | null;
    currentImageInfo?: image.ImageInfo | null;
    logMessages?: string[];
    configFrameInterval?: number;
    configAdaptiveFrameRate?: boolean;
    configMotionDetection?: boolean;
    webSocketService?: WebSocketService;
    videoService?: VideoService;
    realTimeService?: RealTimeAnalysisService | null;
    xComponentController?: XComponentController;
    surfaceId?: string;
}
import hilog from "@ohos:hilog";
import promptAction from "@ohos:promptAction";
import type image from "@ohos:multimedia.image";
import { WebSocketService } from "@normalized:N&&&entry/src/main/ets/services/WebSocketService&";
import { VideoService } from "@normalized:N&&&entry/src/main/ets/services/VideoService&";
import { RealTimeAnalysisService, AnalysisState } from "@normalized:N&&&entry/src/main/ets/services/RealTimeAnalysisService&";
import type { RealTimeAnalysisResult, RealTimeAnalysisConfigOptions } from "@normalized:N&&&entry/src/main/ets/services/RealTimeAnalysisService&";
import type { PlateInfo } from '../model/MessageTypes';
import { PlateAnnotatorCanvas } from "@normalized:N&&&entry/src/main/ets/components/PlateAnnotatorCanvas&";
const DOMAIN = 0x0004;
const TAG = 'RealTimeAnalysisTestPage';
class RealTimeAnalysisTestPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__serviceState = new ObservedPropertySimplePU('未初始化', this, "serviceState");
        this.__errorMessage = new ObservedPropertySimplePU('', this, "errorMessage");
        this.__isConnected = new ObservedPropertySimplePU(false, this, "isConnected");
        this.__isInitialized = new ObservedPropertySimplePU(false, this, "isInitialized");
        this.__isRunning = new ObservedPropertySimplePU(false, this, "isRunning");
        this.__frameCount = new ObservedPropertySimplePU(0, this, "frameCount");
        this.__processingTime = new ObservedPropertySimplePU(0, this, "processingTime");
        this.__recognizedPlates = new ObservedPropertyObjectPU([], this, "recognizedPlates");
        this.__currentPixelMap = new ObservedPropertyObjectPU(null, this, "currentPixelMap");
        this.__currentImageInfo = new ObservedPropertyObjectPU(null, this, "currentImageInfo");
        this.__logMessages = new ObservedPropertyObjectPU([], this, "logMessages");
        this.__configFrameInterval = new ObservedPropertySimplePU(500, this, "configFrameInterval");
        this.__configAdaptiveFrameRate = new ObservedPropertySimplePU(true, this, "configAdaptiveFrameRate");
        this.__configMotionDetection = new ObservedPropertySimplePU(true, this, "configMotionDetection");
        this.webSocketService = new WebSocketService();
        this.videoService = new VideoService();
        this.realTimeService = null;
        this.xComponentController = new XComponentController();
        this.surfaceId = '';
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: RealTimeAnalysisTestPage_Params) {
        if (params.serviceState !== undefined) {
            this.serviceState = params.serviceState;
        }
        if (params.errorMessage !== undefined) {
            this.errorMessage = params.errorMessage;
        }
        if (params.isConnected !== undefined) {
            this.isConnected = params.isConnected;
        }
        if (params.isInitialized !== undefined) {
            this.isInitialized = params.isInitialized;
        }
        if (params.isRunning !== undefined) {
            this.isRunning = params.isRunning;
        }
        if (params.frameCount !== undefined) {
            this.frameCount = params.frameCount;
        }
        if (params.processingTime !== undefined) {
            this.processingTime = params.processingTime;
        }
        if (params.recognizedPlates !== undefined) {
            this.recognizedPlates = params.recognizedPlates;
        }
        if (params.currentPixelMap !== undefined) {
            this.currentPixelMap = params.currentPixelMap;
        }
        if (params.currentImageInfo !== undefined) {
            this.currentImageInfo = params.currentImageInfo;
        }
        if (params.logMessages !== undefined) {
            this.logMessages = params.logMessages;
        }
        if (params.configFrameInterval !== undefined) {
            this.configFrameInterval = params.configFrameInterval;
        }
        if (params.configAdaptiveFrameRate !== undefined) {
            this.configAdaptiveFrameRate = params.configAdaptiveFrameRate;
        }
        if (params.configMotionDetection !== undefined) {
            this.configMotionDetection = params.configMotionDetection;
        }
        if (params.webSocketService !== undefined) {
            this.webSocketService = params.webSocketService;
        }
        if (params.videoService !== undefined) {
            this.videoService = params.videoService;
        }
        if (params.realTimeService !== undefined) {
            this.realTimeService = params.realTimeService;
        }
        if (params.xComponentController !== undefined) {
            this.xComponentController = params.xComponentController;
        }
        if (params.surfaceId !== undefined) {
            this.surfaceId = params.surfaceId;
        }
    }
    updateStateVars(params: RealTimeAnalysisTestPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__serviceState.purgeDependencyOnElmtId(rmElmtId);
        this.__errorMessage.purgeDependencyOnElmtId(rmElmtId);
        this.__isConnected.purgeDependencyOnElmtId(rmElmtId);
        this.__isInitialized.purgeDependencyOnElmtId(rmElmtId);
        this.__isRunning.purgeDependencyOnElmtId(rmElmtId);
        this.__frameCount.purgeDependencyOnElmtId(rmElmtId);
        this.__processingTime.purgeDependencyOnElmtId(rmElmtId);
        this.__recognizedPlates.purgeDependencyOnElmtId(rmElmtId);
        this.__currentPixelMap.purgeDependencyOnElmtId(rmElmtId);
        this.__currentImageInfo.purgeDependencyOnElmtId(rmElmtId);
        this.__logMessages.purgeDependencyOnElmtId(rmElmtId);
        this.__configFrameInterval.purgeDependencyOnElmtId(rmElmtId);
        this.__configAdaptiveFrameRate.purgeDependencyOnElmtId(rmElmtId);
        this.__configMotionDetection.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__serviceState.aboutToBeDeleted();
        this.__errorMessage.aboutToBeDeleted();
        this.__isConnected.aboutToBeDeleted();
        this.__isInitialized.aboutToBeDeleted();
        this.__isRunning.aboutToBeDeleted();
        this.__frameCount.aboutToBeDeleted();
        this.__processingTime.aboutToBeDeleted();
        this.__recognizedPlates.aboutToBeDeleted();
        this.__currentPixelMap.aboutToBeDeleted();
        this.__currentImageInfo.aboutToBeDeleted();
        this.__logMessages.aboutToBeDeleted();
        this.__configFrameInterval.aboutToBeDeleted();
        this.__configAdaptiveFrameRate.aboutToBeDeleted();
        this.__configMotionDetection.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __serviceState: ObservedPropertySimplePU<string>;
    get serviceState() {
        return this.__serviceState.get();
    }
    set serviceState(newValue: string) {
        this.__serviceState.set(newValue);
    }
    private __errorMessage: ObservedPropertySimplePU<string>;
    get errorMessage() {
        return this.__errorMessage.get();
    }
    set errorMessage(newValue: string) {
        this.__errorMessage.set(newValue);
    }
    private __isConnected: ObservedPropertySimplePU<boolean>;
    get isConnected() {
        return this.__isConnected.get();
    }
    set isConnected(newValue: boolean) {
        this.__isConnected.set(newValue);
    }
    private __isInitialized: ObservedPropertySimplePU<boolean>;
    get isInitialized() {
        return this.__isInitialized.get();
    }
    set isInitialized(newValue: boolean) {
        this.__isInitialized.set(newValue);
    }
    private __isRunning: ObservedPropertySimplePU<boolean>;
    get isRunning() {
        return this.__isRunning.get();
    }
    set isRunning(newValue: boolean) {
        this.__isRunning.set(newValue);
    }
    private __frameCount: ObservedPropertySimplePU<number>;
    get frameCount() {
        return this.__frameCount.get();
    }
    set frameCount(newValue: number) {
        this.__frameCount.set(newValue);
    }
    private __processingTime: ObservedPropertySimplePU<number>;
    get processingTime() {
        return this.__processingTime.get();
    }
    set processingTime(newValue: number) {
        this.__processingTime.set(newValue);
    }
    private __recognizedPlates: ObservedPropertyObjectPU<PlateInfo[]>;
    get recognizedPlates() {
        return this.__recognizedPlates.get();
    }
    set recognizedPlates(newValue: PlateInfo[]) {
        this.__recognizedPlates.set(newValue);
    }
    private __currentPixelMap: ObservedPropertyObjectPU<image.PixelMap | null>;
    get currentPixelMap() {
        return this.__currentPixelMap.get();
    }
    set currentPixelMap(newValue: image.PixelMap | null) {
        this.__currentPixelMap.set(newValue);
    }
    private __currentImageInfo: ObservedPropertyObjectPU<image.ImageInfo | null>;
    get currentImageInfo() {
        return this.__currentImageInfo.get();
    }
    set currentImageInfo(newValue: image.ImageInfo | null) {
        this.__currentImageInfo.set(newValue);
    }
    private __logMessages: ObservedPropertyObjectPU<string[]>;
    get logMessages() {
        return this.__logMessages.get();
    }
    set logMessages(newValue: string[]) {
        this.__logMessages.set(newValue);
    }
    private __configFrameInterval: ObservedPropertySimplePU<number>;
    get configFrameInterval() {
        return this.__configFrameInterval.get();
    }
    set configFrameInterval(newValue: number) {
        this.__configFrameInterval.set(newValue);
    }
    private __configAdaptiveFrameRate: ObservedPropertySimplePU<boolean>;
    get configAdaptiveFrameRate() {
        return this.__configAdaptiveFrameRate.get();
    }
    set configAdaptiveFrameRate(newValue: boolean) {
        this.__configAdaptiveFrameRate.set(newValue);
    }
    private __configMotionDetection: ObservedPropertySimplePU<boolean>;
    get configMotionDetection() {
        return this.__configMotionDetection.get();
    }
    set configMotionDetection(newValue: boolean) {
        this.__configMotionDetection.set(newValue);
    }
    // 服务实例
    private webSocketService: WebSocketService;
    private videoService: VideoService;
    private realTimeService: RealTimeAnalysisService | null;
    // XComponent控制器
    private xComponentController: XComponentController;
    private surfaceId: string;
    aboutToAppear() {
        // 初始化WebSocket服务
        this.initWebSocketService();
        // 创建实时分析服务
        const config: RealTimeAnalysisConfigOptions = {
            frameInterval: this.configFrameInterval,
            adaptiveFrameRate: this.configAdaptiveFrameRate,
            motionDetection: this.configMotionDetection
        };
        this.realTimeService = new RealTimeAnalysisService(this.webSocketService, this.videoService, config);
        // 设置服务回调
        this.setupServiceCallbacks();
        this.addLog('页面已加载');
    }
    aboutToDisappear() {
        // 释放资源
        if (this.realTimeService) {
            this.realTimeService.release();
        }
        // 断开WebSocket连接
        this.webSocketService.disconnect();
        this.addLog('页面已卸载');
    }
    /**
     * 初始化WebSocket服务
     */
    private initWebSocketService() {
        // 连接成功回调
        this.webSocketService.onConnect(() => {
            this.isConnected = true;
            this.errorMessage = '';
            this.addLog('WebSocket已连接');
        });
        // 断开连接回调
        this.webSocketService.onDisconnect(() => {
            this.isConnected = false;
            this.errorMessage = '与服务器的连接已断开';
            this.addLog('WebSocket已断开');
        });
        // 错误回调
        this.webSocketService.onError((error: string) => {
            this.errorMessage = error;
            this.addLog(`WebSocket错误: ${error}`);
        });
        // 连接到服务器
        this.webSocketService.connect();
    }
    /**
     * 设置服务回调
     */
    private setupServiceCallbacks() {
        if (!this.realTimeService)
            return;
        // 状态变化回调
        this.realTimeService.onStateChange((state: AnalysisState, message?: string) => {
            this.serviceState = state;
            this.isRunning = state === AnalysisState.RUNNING;
            this.addLog(`服务状态变化: ${state}${message ? `, ${message}` : ''}`);
        });
        // 结果回调
        this.realTimeService.onResult((result: RealTimeAnalysisResult) => {
            this.frameCount++;
            this.processingTime = result.processingTimeMs;
            this.recognizedPlates = result.plates;
            this.addLog(`收到结果: 帧ID=${result.frameId}, 处理时间=${result.processingTimeMs}ms, 车牌数=${result.plates.length}`);
        });
        // 预览帧回调
        this.realTimeService.onPreviewFrame((pixelMap: image.PixelMap) => {
            this.currentPixelMap = pixelMap;
            this.currentImageInfo = pixelMap.getImageInfoSync();
        });
        // 错误回调
        this.realTimeService.onError((error: string) => {
            this.errorMessage = error;
            this.addLog(`服务错误: ${error}`);
        });
    }
    /**
     * 初始化服务
     */
    private async initializeService() {
        if (!this.realTimeService)
            return;
        this.addLog('正在初始化服务...');
        const success = await this.realTimeService.initialize();
        if (success) {
            this.isInitialized = true;
            this.addLog('服务初始化成功');
            promptAction.showToast({ message: '服务初始化成功', duration: 2000 });
        }
        else {
            this.isInitialized = false;
            this.addLog(`服务初始化失败: ${this.realTimeService.getErrorMessage()}`);
            promptAction.showToast({ message: `初始化失败: ${this.realTimeService.getErrorMessage()}`, duration: 3000 });
        }
    }
    /**
     * 启动分析
     */
    private async startAnalysis() {
        if (!this.realTimeService || !this.isInitialized) {
            promptAction.showToast({ message: '服务未初始化', duration: 2000 });
            return;
        }
        if (!this.surfaceId) {
            promptAction.showToast({ message: 'Surface ID未获取', duration: 2000 });
            return;
        }
        this.addLog('正在启动分析...');
        const success = await this.realTimeService.startAnalysis(this.surfaceId);
        if (success) {
            this.isRunning = true;
            this.addLog('分析已启动');
            promptAction.showToast({ message: '分析已启动', duration: 2000 });
        }
        else {
            this.isRunning = false;
            this.addLog(`启动分析失败: ${this.realTimeService.getErrorMessage()}`);
            promptAction.showToast({ message: `启动失败: ${this.realTimeService.getErrorMessage()}`, duration: 3000 });
        }
    }
    /**
     * 暂停分析
     */
    private pauseAnalysis() {
        if (!this.realTimeService || !this.isRunning)
            return;
        this.realTimeService.pauseAnalysis();
        this.addLog('分析已暂停');
        promptAction.showToast({ message: '分析已暂停', duration: 2000 });
    }
    /**
     * 恢复分析
     */
    private resumeAnalysis() {
        if (!this.realTimeService || this.isRunning)
            return;
        this.realTimeService.resumeAnalysis();
        this.addLog('分析已恢复');
        promptAction.showToast({ message: '分析已恢复', duration: 2000 });
    }
    /**
     * 停止分析
     */
    private async stopAnalysis() {
        if (!this.realTimeService)
            return;
        await this.realTimeService.stopAnalysis();
        this.isRunning = false;
        this.addLog('分析已停止');
        promptAction.showToast({ message: '分析已停止', duration: 2000 });
    }
    /**
     * 更新配置
     */
    private updateConfig() {
        if (!this.realTimeService)
            return;
        const config: RealTimeAnalysisConfigOptions = {
            frameInterval: this.configFrameInterval,
            adaptiveFrameRate: this.configAdaptiveFrameRate,
            motionDetection: this.configMotionDetection
        };
        this.realTimeService.updateConfig(config);
        this.addLog(`配置已更新: 帧间隔=${this.configFrameInterval}ms, 自适应帧率=${this.configAdaptiveFrameRate}, 运动检测=${this.configMotionDetection}`);
        promptAction.showToast({ message: '配置已更新', duration: 2000 });
    }
    /**
     * 添加日志
     */
    private addLog(message: string) {
        const timestamp = new Date().toLocaleTimeString();
        const logMessage = `[${timestamp}] ${message}`;
        this.logMessages = [logMessage, ...this.logMessages];
        // 限制日志数量
        if (this.logMessages.length > 50) {
            this.logMessages = this.logMessages.slice(0, 50);
        }
        hilog.info(DOMAIN, TAG, message);
    }
    /**
     * 清空日志
     */
    private clearLogs() {
        this.logMessages = [];
        this.addLog('日志已清空');
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(270:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#FAFAFA');
            Column.padding(16);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 标题栏
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(272:7)", "entry");
            // 标题栏
            Row.width('100%');
            // 标题栏
            Row.padding(16);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('实时分析服务测试');
            Text.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(273:9)", "entry");
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(277:9)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.isConnected ? '已连接' : '未连接');
            Text.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(279:9)", "entry");
            Text.fontSize(14);
            Text.fontColor(this.isConnected ? '#4CAF50' : '#F44336');
        }, Text);
        Text.pop();
        // 标题栏
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // 错误信息
            if (this.errorMessage) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.errorMessage);
                        Text.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(288:9)", "entry");
                        Text.width('100%');
                        Text.fontSize(14);
                        Text.fontColor('#F44336');
                        Text.backgroundColor('#FFEBEE');
                        Text.padding(8);
                        Text.margin({ bottom: 8 });
                    }, Text);
                    Text.pop();
                });
            }
            // 服务状态
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 服务状态
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(298:7)", "entry");
            // 服务状态
            Row.width('100%');
            // 服务状态
            Row.padding(8);
            // 服务状态
            Row.margin({ bottom: 8 });
            // 服务状态
            Row.backgroundColor('#E3F2FD');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`服务状态: ${this.serviceState}`);
            Text.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(299:9)", "entry");
            Text.fontSize(16);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(302:9)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`帧数: ${this.frameCount}`);
            Text.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(304:9)", "entry");
            Text.fontSize(16);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(307:9)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`处理时间: ${this.processingTime}ms`);
            Text.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(309:9)", "entry");
            Text.fontSize(16);
        }, Text);
        Text.pop();
        // 服务状态
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 摄像头预览
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(318:7)", "entry");
            // 摄像头预览
            Stack.width('100%');
            // 摄像头预览
            Stack.height(240);
            // 摄像头预览
            Stack.margin({ bottom: 8 });
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // XComponent用于摄像头预览
            XComponent.create({
                id: 'previewComponent',
                type: 'surface',
                controller: this.xComponentController
            }, "com.example.yolo1/entry");
            XComponent.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(320:9)", "entry");
            // XComponent用于摄像头预览
            XComponent.width('100%');
            // XComponent用于摄像头预览
            XComponent.height(240);
            // XComponent用于摄像头预览
            XComponent.backgroundColor('#000000');
            // XComponent用于摄像头预览
            XComponent.onLoad(() => {
                this.surfaceId = this.xComponentController.getXComponentSurfaceId();
                this.addLog(`XComponent加载完成，Surface ID: ${this.surfaceId}`);
            });
        }, XComponent);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // 如果有当前帧和识别结果，显示标注
            if (this.currentPixelMap && this.currentImageInfo) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        __Common__.create();
                        __Common__.width('100%');
                    }, __Common__);
                    {
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            if (isInitialRender) {
                                let componentCall = new PlateAnnotatorCanvas(this, {
                                    pixelMap: this.currentPixelMap,
                                    plates: this.recognizedPlates,
                                    canvasDisplayHeight: 240,
                                    imageInfo: this.currentImageInfo
                                }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets", line: 335, col: 11 });
                                ViewPU.create(componentCall);
                                let paramsLambda = () => {
                                    return {
                                        pixelMap: this.currentPixelMap,
                                        plates: this.recognizedPlates,
                                        canvasDisplayHeight: 240,
                                        imageInfo: this.currentImageInfo
                                    };
                                };
                                componentCall.paramsGenerator_ = paramsLambda;
                            }
                            else {
                                this.updateStateVarsOfChildByElmtId(elmtId, {
                                    pixelMap: this.currentPixelMap,
                                    plates: this.recognizedPlates,
                                    canvasDisplayHeight: 240,
                                    imageInfo: this.currentImageInfo
                                });
                            }
                        }, { name: "PlateAnnotatorCanvas" });
                    }
                    __Common__.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        // 摄像头预览
        Stack.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 控制按钮
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(349:7)", "entry");
            // 控制按钮
            Row.width('100%');
            // 控制按钮
            Row.justifyContent(FlexAlign.SpaceEvenly);
            // 控制按钮
            Row.margin({ bottom: 8 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('初始化');
            Button.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(350:9)", "entry");
            Button.onClick(() => this.initializeService());
            Button.enabled(!this.isInitialized);
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel(this.isRunning ? '暂停' : '启动');
            Button.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(354:9)", "entry");
            Button.onClick(() => {
                if (this.isRunning) {
                    this.pauseAnalysis();
                }
                else {
                    if (this.serviceState === AnalysisState.PAUSED) {
                        this.resumeAnalysis();
                    }
                    else {
                        this.startAnalysis();
                    }
                }
            });
            Button.enabled(this.isInitialized);
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('停止');
            Button.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(368:9)", "entry");
            Button.onClick(() => this.stopAnalysis());
            Button.enabled(this.isInitialized && (this.isRunning || this.serviceState === AnalysisState.PAUSED));
        }, Button);
        Button.pop();
        // 控制按钮
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 配置选项
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(377:7)", "entry");
            // 配置选项
            Column.width('100%');
            // 配置选项
            Column.padding(8);
            // 配置选项
            Column.backgroundColor('#F5F5F5');
            // 配置选项
            Column.margin({ bottom: 8 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('配置选项');
            Text.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(378:9)", "entry");
            Text.fontSize(16);
            Text.fontWeight(FontWeight.Bold);
            Text.margin({ bottom: 8 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(383:9)", "entry");
            Row.width('100%');
            Row.margin({ bottom: 4 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('帧间隔(ms):');
            Text.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(384:11)", "entry");
            Text.fontSize(14);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Slider.create({
                min: 100,
                max: 2000,
                step: 100,
                value: this.configFrameInterval
            });
            Slider.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(387:11)", "entry");
            Slider.onChange((value: number) => {
                this.configFrameInterval = value;
            });
            Slider.layoutWeight(1);
        }, Slider);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`${this.configFrameInterval}`);
            Text.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(398:11)", "entry");
            Text.fontSize(14);
            Text.width(40);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(405:9)", "entry");
            Row.width('100%');
            Row.margin({ bottom: 4 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('自适应帧率:');
            Text.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(406:11)", "entry");
            Text.fontSize(14);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(409:11)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Toggle.create({ type: ToggleType.Switch, isOn: this.configAdaptiveFrameRate });
            Toggle.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(411:11)", "entry");
            Toggle.onChange((isOn: boolean) => {
                this.configAdaptiveFrameRate = isOn;
            });
        }, Toggle);
        Toggle.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(419:9)", "entry");
            Row.width('100%');
            Row.margin({ bottom: 4 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('运动检测:');
            Text.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(420:11)", "entry");
            Text.fontSize(14);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(423:11)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Toggle.create({ type: ToggleType.Switch, isOn: this.configMotionDetection });
            Toggle.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(425:11)", "entry");
            Toggle.onChange((isOn: boolean) => {
                this.configMotionDetection = isOn;
            });
        }, Toggle);
        Toggle.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('应用配置');
            Button.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(433:9)", "entry");
            Button.onClick(() => this.updateConfig());
            Button.width('100%');
        }, Button);
        Button.pop();
        // 配置选项
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 日志区域
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(443:7)", "entry");
            // 日志区域
            Column.width('100%');
            // 日志区域
            Column.padding(8);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(444:9)", "entry");
            Row.width('100%');
            Row.margin({ bottom: 4 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('日志');
            Text.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(445:11)", "entry");
            Text.fontSize(16);
            Text.fontWeight(FontWeight.Bold);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(449:11)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('清空');
            Button.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(451:11)", "entry");
            Button.fontSize(14);
            Button.height(28);
            Button.onClick(() => this.clearLogs());
        }, Button);
        Button.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            List.create();
            List.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(459:9)", "entry");
            List.width('100%');
            List.height(120);
            List.backgroundColor('#FFFFFF');
            List.border({ width: 1, color: '#DDDDDD', radius: 4 });
        }, List);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const log = _item;
                {
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        itemCreation2(elmtId, isInitialRender);
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        ListItem.create(deepRenderFunction, true);
                        ListItem.height(20);
                        ListItem.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(461:13)", "entry");
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(log);
                            Text.debugLine("entry/src/main/ets/pages/RealTimeAnalysisTestPage.ets(462:15)", "entry");
                            Text.fontSize(12);
                            Text.width('100%');
                        }, Text);
                        Text.pop();
                        ListItem.pop();
                    };
                    this.observeComponentCreation2(itemCreation2, ListItem);
                    ListItem.pop();
                }
            };
            this.forEachUpdateFunction(elmtId, this.logMessages, forEachItemGenFunction);
        }, ForEach);
        ForEach.pop();
        List.pop();
        // 日志区域
        Column.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "RealTimeAnalysisTestPage";
    }
}
registerNamedRoute(() => new RealTimeAnalysisTestPage(undefined, {}), "", { bundleName: "com.example.yolo1", moduleName: "entry", pagePath: "pages/RealTimeAnalysisTestPage", pageFullPath: "entry/src/main/ets/pages/RealTimeAnalysisTestPage", integratedHsp: "false", moduleType: "followWithHap" });
